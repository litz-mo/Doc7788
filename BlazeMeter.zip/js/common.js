function enableBtn(btnid) {
    document.getElementById(btnid).style.display = "inline-block";
    document.getElementById(btnid + "-off").style.display = "none";
}

function disableBtn(btnid) {
    document.getElementById(btnid).style.display = "none";
    document.getElementById(btnid + "-off").style.display = "inline-block";
}

function isLogged() {
    if ("false" === localStorage.getItem("logged"))
        return false;
    else
        return true;
}


function waitOverlay(progress_bar) {
    enableOverlay();
    $("#run-overlay .progress-body").show();
    $("#run-overlay .domains-body").hide();
    $("#run-overlay .progressbar").progressbar({
        value: progress_bar
    });
}

function domainOverlay(domains) {
    $('#run-overlay .close').show();
    enableOverlay();
    $("#run-overlay .domains-body").show();
    var domain_choice = '';
    for (var index in domains) {
        domain_choice += '<div class="checkbox-wrapper">' +
            '<input type="checkbox" name="domains" id="domain-' + index + '" value="' + domains[index] + '"/>' +
            '<label for="domain-' + index + '"><span></span>' + domains[index] + '</label></div>';
    }
    $("#run-overlay .domains-body .include-domains").html(domain_choice);
}

function testEndedOverlay() {
    $('#run-overlay .close').hide();
    document.querySelector('#run-overlay .test-ended-body .button').addEventListener('click',
        closeTestEndedOverlay);
    enableOverlay();
    $("#run-overlay .body").hide();
    $("#run-overlay .test-ended-body").show();
}

function enableOverlay() {
    $("#run-overlay").show();
}

function closeOverlay() {

    if ($("#advanced-options-fieldset").length) {
        document.getElementById("advanced-options-fieldset").className = '';
        document.getElementById("advanced-options").style.display = 'none';
    }
    if ($("#run-overlay .progress-body").is(":visible")) {
        //This is run test overlay, we need to remove the overlay so that the progressbar doesn't renable it again
        $("#run-overlay").remove();
    }
    else {
        $("#run-overlay").hide();
    }
}

function closeTestEndedOverlay() {
    //Acknowledge that test was stopped
    chrome.storage.local.set({
        'stopped_test': false
    });
    closeOverlay();
}

function uploadSelectedDomains() {
    setDomains();
    chrome.extension.sendRequest({
        type: 'upload_traffic'
    }, function (data) {
        $("#run-overlay .domains-body").hide();
        closeOverlay();
        var status = document.getElementById("status");
        status.innerHTML = "<img width=16px height=16px src='../images/upload.gif'/>";
    });
}

function exportSelectedDomains() {
    setDomains();
    chrome.storage.local.get('mode', function (data) {
        if (data.mode == 'mode-follow') {
            chrome.extension.sendRequest({
                type: 'export_jmeter_follow'
            }, function (data) {
                $("#run-overlay .domains-body").hide();
                closeOverlay();
                var status = document.getElementById("status");
                status.innerHTML = "Converting...";
            });
        } else {
            chrome.extension.sendRequest({
                type: 'export_jmeter'
            }, function (data) {
                $("#run-overlay .domains-body").hide();
                closeOverlay();
                var status = document.getElementById("status");
                status.innerHTML = "Converting...";
            });
        }
    });
}

function setDomains() {
    var domains = {};
    $("input:checkbox[name=domains]:checked").each(function () {
        domains[$(this).val()] = $(this).val();
    });

    chrome.storage.local.set({'selected_domains': domains});
}

function dismissTest() {
    chrome.extension.sendRequest({
        type: 'dismiss_test'
    }, function (data) {
        chrome.storage.local.set({
            'start_recording_mode': ''
        });
        $("#run-overlay .progress-body").hide();
        closeOverlay();
    });
}

function cancelTest() {
    console.log("in canceltest");
    chrome.extension.sendRequest({
        type: 'cancel_test'
    }, function (data) {

        var status = document.getElementById("status");
        status.innerHTML = "";
        $("#run-overlay .progress-body").hide();
        //closeOverlay();
    });
}