//@todo: change advanced options to be saved on change
var manifest = chrome.runtime.getManifest();
var server_url = localStorage.getItem("server");
var op = "stopped";
var options = new Object();
var name_default = "Enter the name of the test";
var debug = false;
var oldapi = false;
var mode = '';
var start_recording_mode = '';
var availableTests = new Array();
var default_location = "eu-west-1";
var default_concurrency = 50;
var useragentlist = new Object();
var DEFAULT_CONCURRENCY_MAX = 100;
var MAX_FOLLOW_ME_LIMIT = 10000;
var MAX_RECORDING_LIMIT = 18000;
var max_concurrent_users = DEFAULT_CONCURRENCY_MAX;

$("#add-concurrency").click(function () {
    //Change concurrency when "+" button is clicked
    if (op == 'stopped' && mode != 'mode-record' && isLogged()) {
        changeSliderMax();
    }
});

//Init
chrome.storage.local.set({
    'selected_domains': {}
});

if (localStorage.getItem("debug") == 'true') {
    console.log("Debug mode");
    debug = true;
}

if (localStorage.getItem("oldapi") == 'true') {
    console.log("Using Old API");
    oldapi = true;
}

$(document).ready(function () {
        $("#signup").attr("href", server_url + "/user/register?app=chrome&ver=" + manifest.version);
        $("#login").attr("href", server_url + "/user?app=chrome&ver=" + manifest.version);
        $(".version").html(manifest.version);
        $('#top_level').change(function () {
            saveAdvancedOptions();
        });
        $('#cache').change(function () {
            saveAdvancedOptions();
        });
        $('#cookie').change(function () {
            saveAdvancedOptions();
        });
        $('#options').change(function () {
            saveAdvancedOptions();
        });
    }
);

// user agent parse json and set from storage
$.getJSON("js/useragentslist.js", function (data) {

    var list = $('#user-agents-list');
    $.each(data.UserAgentList, function (key, value) {
        var list_group = '<optgroup label="' + value.Id + '">' + value.Name + '</optgroup>';

        $.each(value.UserAgents, function (key1, value1) {
            var list_option = '<option value="' + value1.Id + '">' + value1.Name + '</option>';
            list_group += list_option;
            useragentlist[value1.Id] = value1.UserAgent;
        });
        list.append(list_group);
    });

    chrome.storage.local.get('options', function (items) {
        if (items.options && items.options.useragent) {
            $('#user-agents-list').val(items.options.useragent);
        } else {
            $('#user-agents-list').val("Default");
        }
    });

    return false;
});

// chrome.storage.local.set({'mode': ''});
chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.status) {
        var status = document.getElementById("status");
        status.innerHTML = request.status;
    } else if (request.waiting) {
        if (request.waiting == "failed") {
            op = 'stopped';
            initFollowMeInterface();
            initRecordInterface();
            document.getElementById("follow-name").disabled = false;
            $('#overlay').remove();
        } else {
            // Follow mode running
            disableBtn("follow-record");
            disableBtn("follow-reset");
            enableBtn("follow-pause");
            enableBtn("follow-stop");
            enableBtn("follow-report");
            // When the test is running, the load origin becomes read only.
            document.getElementById("load-origin").disabled = true;
            // When the test is running, the select script becomes read only.
            document.getElementById("follow-name").disabled = true;
        }
    } else if (request.op == "progressbar") {
        if (request.progress) {
            if (request.follow) {
                $('#run-overlay .close').hide();
                $('.text p').text('Launching servers in the cloud can take about 2 minutes.');
                $('.text h4').text('Please wait while cloud servers are being launched.');
            }
            else {
                $('#run-overlay .close').show();
                if ($('#options').is(':checked')) {
                    $('.text p').text('');
                    $('.text h4').text('Uploading your data.');
                    $('#run-overlay .close').hide();
                } else {
                    $('.text p').text('Launching servers in the cloud can take about 2 minutes.');
                    $('.text h4').text('Please wait while cloud servers are being launched.');
                }
            }

            if (request.test_id) {
                document.querySelector('#run-overlay .progress-body .button').addEventListener('click',
                    dismissTest);
                document.querySelector('#run-overlay .progress-body .button').style.display = 'block';
            } else {
                //if($('#run-overlay .progress-body').length){
                document.querySelector('#run-overlay .progress-body .button').removeEventListener('click',
                    dismissTest);
                document.querySelector('#run-overlay .progress-body .button').style.display = 'none';
                document.querySelector('#run-overlay .close').removeEventListener('click',
                    closeOverlay);
                document.querySelector('#run-overlay .close').addEventListener('click',
                    cancelTest);
                //}

            }

            waitOverlay(request.progress);
        } else {
            $("#run-overlay .progress-body").hide();
            closeOverlay();
            if (request.followstopped) {
                // enable default values
                $("#concurrency").slider("option", "max", localStorage.getItem("real_max_follow_limit"));
                // $("#concurrency").slider("option", "max", max_concurrent_users);
            }
        }
    } else if (request.op == "domainoverlay") {
        var status = document.getElementById("status");
        status.innerHTML = '';
        document.querySelector('#run-overlay .close').addEventListener('click', closeOverlay);

        if (request.action == 'upload') {
            document.querySelector('#run-overlay .domains-body .button').addEventListener('click',
                uploadSelectedDomains);
        } else if (request.action == 'export') {
            document.querySelector('#run-overlay .domains-body .button').addEventListener('click',
                exportSelectedDomains);
        }

        domainOverlay(JSON.parse(request.domains));
    }
    else if (request.op == "testendedoverlay") {
        var status = document.getElementById("status");
        status.innerHTML = '';
        testEndedOverlay();
    }
    else if (request.op == "stop_recording") {
        stopRecording();
        $('#regex_include').css('border-color', 'red');

    }
    else if (request.op == "continue_recording") {
        $('#regex_include').css('border', 'none');
    }
    else if (request.op == "network_error") {
        resetRecording();
    }
});

// Record/Follow Me switch
$('.onoffswitch-checkbox').click(function (e) {
    if (op != 'stopped' && mode == 'mode-record' && start_recording_mode == 'mode-record') {
        e.preventDefault();
        return;
    } else {
        mode = $(this).val();
        toggleMode();
        chrome.storage.local.set({
            'mode': mode
        });
        chrome.extension.sendRequest({
            type: 'switch_mode'
        }, function (data) {

        });

        if (op != 'stopped' && op != 'pause') {
            document.getElementById("status").innerHTML = "";
            disableBtn("record");
            enableBtn("pause");
            enableBtn("stop");
        }
    }
});

var updateSliderLabel_timedistribution = function (newValue) {
    localStorage.setItem('time-distribution', newValue);
    if (newValue == 0) {
        autoTimeDistribution(localStorage["concurrency"]);
    }
    else {
        $('#time-distribution-display-textfield').val(newValue);
    }
};

var stopSliderLabel = function (newValue) {
    //when user released the mouse button and the value now is less or equal to previous step, then decrease the limit to that step.
    if (op == 'stopped' && mode != 'mode-record' && isLogged()) {
        var user_max_conc = localStorage.getItem("real_max_follow_limit");
        var concurrency_current_new = Math.min(100, user_max_conc);
        if (newValue <= 1000 && newValue > 100) {
            concurrency_current_new = Math.min(1000, user_max_conc);
        }
        else if (newValue <= 10000 && newValue > 1000) {
            concurrency_current_new = Math.min(10000, user_max_conc);
        }
        else if (newValue <= 50000 && newValue > 10000) {
            concurrency_current_new = Math.min(50000, user_max_conc);
        }
        else if (newValue <= 100000 && newValue > 50000) {
            concurrency_current_new = Math.min(100000, user_max_conc);
        }
        else if (newValue > 100000) {
            concurrency_current_new = user_max_conc;
        }

        if (concurrency_current_new != user_max_conc) {
            $("#add-concurrency").show();
        }
        $("#concurrency").slider("option", "max", concurrency_current_new);
    }
};

var updateSliderLabel = function (newVal) {
    $('#concurrency-display-textfield').val(newVal);
    localStorage.setItem('concurrency', newVal);
    updateLoadLabel(newVal);
    if (localStorage.getItem("time-distribution") == '0') {
        autoTimeDistribution(newVal);
    }
};

chrome.storage.local.get(null, function (all) {

    if (!localStorage.getItem("concurrency")) {
        localStorage.setItem("concurrency", default_concurrency);
    }
    // Concurrency slider
    $("#concurrency").slider({
        range: "max",
        min: 1,
        max: max_concurrent_users,
        value: localStorage.getItem("concurrency"),
        slide: function (event, ui) {
            updateSliderLabel(ui.value);
        },
        stop: function (event, ui) {
            stopSliderLabel(ui.value);
        }
    });
    updateLoadLabel(localStorage.getItem("concurrency"));
    $("#time-distribution-display-textfield").attr("disabled", "disabled");
    $("#time-distribution").slider({
        range: "max",
        min: 0,
        max: 300,
        step: 10,
        value: localStorage.getItem("time-distribution"),
        slide: function (event, ui) {
            updateSliderLabel_timedistribution(ui.value);
        }
    });

    if (localStorage.getItem("time-distribution") == '0') {
        autoTimeDistribution(localStorage.getItem("concurrency"));
    }
    else {
        $("#time-distribution-display-textfield").val(localStorage.getItem("time-distribution"));
        $('#time-distribution').slider("option", "value", localStorage.getItem("time-distribution"));
    }

    $(document).ready(function () {
        $("#time-distribution .ui-slider-range").attr("original-title", "Set the time interval during which FollowMe's virtual users will start 'following' your online activity. The virtual users will join randomly during this specified period.");
        $(".time-distribution-display").attr("original-title", "Set the time interval during which FollowMe's virtual users will start 'following' your online activity. The virtual users will join randomly during this specified period.");
        $('#time-distribution .ui-slider-range').tipsy({
            gravity: 'n'
        });
        $('.time-distribution-display').tipsy({
            gravity: 'nw'
        });
    });
    mode = all.mode;
    start_recording_mode = all.start_recording_mode;

    chrome.extension.sendRequest({
        type: 'get_status'
    }, function (data) {
        op = data.op;
        toggleMode();
        if (op == "record") {
            // Record mode running
            disableBtn("record");
            disableBtn("reset");
            enableBtn("pause");
            enableBtn("stop");
        } else if (op == "follow") {
            // Follow mode running
            disableBtn("follow-record");
            disableBtn("follow-reset");
            enableBtn("follow-pause");
            enableBtn("follow-stop");
            enableBtn("follow-report");
            // When the test is running, the load origin becomes read only.
            document.getElementById("load-origin").disabled = true;
            // When the test is running, the select script becomes read only.
            document.getElementById("follow-name").disabled = true;

            // Recording is also running if following
            disableBtn("record");
            disableBtn("reset");
            enableBtn("pause");
            enableBtn("stop");
        } else if (op == 'pause') {
            enableBtn("follow-stop");
            // When the test is running, the load origin becomes read only.
            document.getElementById("load-origin").disabled = true;
            // When the test is running, the select script becomes read only.
            document.getElementById("follow-name").disabled = true;
            enableBtn("stop");
            disableBtn("follow-pause");
            enableBtn("follow-record");
            disableBtn("pause");
            enableBtn("reset");
            if (start_recording_mode == 'mode-record') {
                enableBtn("record");
            } else {
                disableBtn("record");
            }
        } else if (op == 'waiting') {
            waitOverlay(1);
        } else if (op == 'stopped') {
            if (all.test_id) {
                enableBtn("follow-report");
            }

            chrome.extension.sendRequest({
                type: 'traffic_exists'
            }, function (exists) {
                if (exists && localStorage.getItem("name") && localStorage.getItem("name") != "") {
                    // Enable edit button if there is data to edit
                    enableBtn("edit");
                    if (isLogged()) {
                        enableBtn("upload");
                    }
                    enableBtn("upload-jmx");
                } else {
                    disableBtn("edit");
                    disableBtn("upload");
                    disableBtn("upload-jmx");
                }
            });

            chrome.extension.sendRequest({
                type: 'traffic_exists_follow'
            }, function (exists) {
                if (exists) {
                    enableBtn("follow-report");
                    enableBtn("follow-upload-jmx");
                }
            });

        } else {
            enableBtn("record");
            enableBtn("reset");
            disableBtn("pause");
            disableBtn("stop");
        }
    });
    if (all.stopped_test) {
        testEndedOverlay();
    }
});

/*
 $("#name").change(function () {
 var value = parseInt(this.value);
 localStorage.setItem("jmxname", value);
 });

 $("#follow-name").change(function () {
 var value = parseInt(this.value);
 console.log(value);
 localStorage.setItem("jmxname", value);
 });*/

// Concurrency textfield
$("#concurrency-display-textfield").change(function () {
    var value = parseInt(this.value);
    if (isNaN(value)) {
        value = default_concurrency;
        $("#concurrency-display-textfield").val(default_concurrency);
    }
    else if (op == 'follow') {
        var follow_max = $("#concurrency").slider("option", "max");
        if (value > follow_max) {
            $("#concurrency").slider("value", follow_max);
            $("#concurrency-display-textfield").val(follow_max);
            value = follow_max;
        }
    }
    else if (value > localStorage.getItem("real_max_follow_limit")) {
        value = localStorage.getItem("real_max_follow_limit");
        $("#concurrency-display-textfield").val(value);
    }
    $("#concurrency").slider("value", value);
    localStorage.setItem("concurrency", value);
    updateLoadLabel(value);
    if(op != 'follow') {
        changeSliderMax();
    }
});

getTestsAndUserLimits();

document
    .addEventListener(
    "DOMContentLoaded",
    function () {

        $('#load-origin').on('change', function () {
            chrome.storage.local.set({
                'location': this.value
            });
        });

        /*
         * The start has two functions: 1. Run 2. Edit change the tipsy
         * according to the checkbox
         */
        $('#options')
            .change(
            function () {
                if (isLogged()) {
                    if ($(this).is(":checked")) {
                        document.getElementById("upload").title = "Adjust test properties and run from the cloud.";
                        document.getElementById("upload-off").title = "Adjust test properties and run from the cloud. ";
                    } else {
                        document.getElementById("upload").title = "Click to run from the cloud now.";
                        document.getElementById("upload-off").title = "Click to run from the cloud now.";
                    }
                }
            });

        // Add tipsy to buttons
        $('#record').tipsy({
            gravity: 'nw'
        });
        $('.onoffswitch-label').tipsy({
            gravity: 'nw'
        });
        $('#record-off').tipsy({
            gravity: 'nw'
        });
        $('#upload').tipsy({
            gravity: 'ne'
        });
        $('#upload-off').tipsy({
            gravity: 'ne'
        });
        $('#follow-record').tipsy({
            gravity: 'ne'
        });
        $('#follow-record-off').tipsy({
            gravity: 'ne'
        });
        $('#follow-stop').tipsy({
            gravity: 'nw'
        });
        $('#follow-stop-off').tipsy({
            gravity: 'nw'
        });
        $('#reset').tipsy({
            gravity: 'ne'
        });
        $('#reset-off').tipsy({
            gravity: 'ne'
        });
        $('.tipsy-btn').tipsy({
            gravity: 'n'
        });
        $('#add-concurrency').tipsy({
            gravity: 'n'
        });
        $('.description').tipsy({
            gravity: 'ne'
        });

        // Button actions
        document.querySelector('#upload').addEventListener('click', uploadData);
        document.querySelector('#upload-jmx').addEventListener('click', exportJmeter);
        document.querySelector('#edit').addEventListener('click', editData);
        document.querySelector('#pause').addEventListener('click', pauseRecording);
        document.querySelector('#stop').addEventListener('click', stopRecording);
        document.querySelector('#record').addEventListener('click', startRecording);
        document.querySelector('#reset').addEventListener('click', resetRecording);
        // Advanced fieldset
        document.querySelector('#advanced-options-fieldset').addEventListener('click',
            expandOptions);

        // Follow me
        document.querySelector('#follow-record').addEventListener('click', startFollow);
        document.querySelector('#follow-stop').addEventListener('click', stopRecording);
        document.querySelector('#follow-pause').addEventListener('click', pauseRecording);
        document.querySelector('#follow-upload-jmx').addEventListener('click', exportJmeter);
        document.querySelector('#follow-report').addEventListener('click', viewReport);
        document.querySelector('#follow-reset').addEventListener('click', resetRecording);

        // Overlay close button
        document.querySelector('#run-overlay .close').addEventListener('click', closeOverlay);
        document.querySelector('#user-agents-list').addEventListener('change', changeUserAgent);

        // Name default value:
        if (document.getElementById("name").value == "") {
            document.getElementById("name").value = name_default;
        }

        if (document.getElementById("follow-name").value == "") {
            document.getElementById("follow-name").value = name_default;
        }

        document.querySelector('#name').onfocus = function () {
            if (this.value == name_default) {
                this.value = "";
            }
        };
        document.querySelector('#name').onblur = function () {
            if (this.value == "") {
                this.value = name_default;
            }
        };

        document.querySelector('#follow-name').onfocus = function () {
            if (this.value == name_default) {
                this.value = "";
            }
        };
        document.querySelector('#follow-name').onblur = function () {
            if (this.value == "") {
                this.value = name_default;
            }
        };

        // Save name on out of focus
        document.querySelector('#name').onkeyup = function () {
            if (document.getElementById("name").value != name_default) {
                localStorage.setItem("name", document.getElementById("name").value);
                localStorage.setItem("jmxname", document.getElementById("name").value);
            }
            if (document.getElementById("name").value == "") {
                disableBtn("edit");
                disableBtn("upload");
                disableBtn("upload-jmx");
            } else {
                chrome.extension.sendRequest({
                    type: 'get_status'
                }, function (data) {
                    op = data.op;
                    chrome.extension.sendRequest({
                        type: 'trafic_exists'
                    }, function (exists) {
                        if (exists && op == "stopped") {
                            // Enable edit button if there is data to edit
                            enableBtn("edit");
                            if (isLogged()) {
                                enableBtn("upload");
                                enableBtn("upload-jmx");
                            }
                        }
                    });
                });
            }
        };

        // Save name on out of focus
        document.querySelector('#follow-name').onkeyup = function () {
            if (document.getElementById("follow-name").value == "") {
                disableBtn("follow-record");
            }
            else {
                localStorage.setItem("name", document.getElementById("follow-name").value);
                localStorage.setItem("jmxname", document.getElementById("follow-name").value);
                if (isLogged() && document.getElementById("regex_follow_input").value != "") {
                    enableBtn("follow-record");
                }
            }
        };

        // Retrieve default options
        chrome.storage.local.get('options', function (items) {
            if (JSON.stringify(items) != "{}") {
                options = items.options;
                if (localStorage.getItem("name"))
                    document.getElementById("name").value = localStorage.getItem("name");
                document.getElementById("regex_include").value = options.regex_include;
                if (options.regex_follow_input) {
                    document.getElementById("regex_follow_input").value = options.regex_follow_input;
                } else {
                    document.getElementById("regex_follow_input").value = '';
                }
                document.getElementById("top_level").checked = options.top_level;
                document.getElementById("cookie").checked = options.cookie;
                document.getElementById("cache").checked = options.cache;
                document.getElementById("options").checked = options.options;
            }
        });

        // Save regex follow
        document.getElementById("regex_follow_input").onkeyup = function () {
            if (document.getElementById("regex_follow_input").value == "") {
                disableBtn("follow-record");
            }
            else {
                if (isLogged() && document.getElementById("follow-name").value != "" && op == 'stopped') {
                    enableBtn("follow-record");
                }
            }
            saveAdvancedOptions();
            chrome.extension.sendRequest({
                type: 'change_regex_follow_input'
            }, function (data) {
            });
        }

        initFollowMeOptions();
        initRecordInterface();
    });

function startRecording() {
    op = 'record';

    start_recording_mode = mode;
    chrome.storage.local.set({
        'start_recording_mode': mode
    });

    // Set options
    saveAdvancedOptions();

    disableBtn("edit");
    disableBtn("upload");
    disableBtn("upload-jmx");
    disableBtn("reset");

    $('#load-origin').prop('disabled', true);
    $('#user-agents-list').prop('disabled', true);
    $('#top_level').prop('disabled', true);
    $('#cache').prop('disabled', true);
    $('#cookie').prop('disabled', true);

    $('#options').prop(function () {
        saveAdvancedOptions();
    });
    var status = document.getElementById("status");
    status.innerHTML = "";

    disableBtn("record");
    enableBtn("pause");
    enableBtn("stop");

    chrome.extension.sendRequest({
        type: 'start_traffic'
    }, function (data) {
    });
}

function resetRecording() {
    op = 'stopped';
    start_recording_mode = '';
    chrome.storage.local.set({
        'start_recording_mode': ''
    });

    chrome.extension.sendRequest({
        type: 'reset_traffic'
    }, function (data) {

        chrome.storage.local.set({
            'test_id': null
        });
        chrome.storage.local.set({
            'test_name': name_default
        });
        // chrome.storage.local.set({'concurrency': 1});
        localStorage.setItem("concurrency", "50");
        localStorage.setItem("time-distribution", "0");
        $("#concurrency").slider("option", "value", "50");
        if (mode == 'mode-follow') {
            var user_max_limit = localStorage.getItem("real_max_follow_limit");
            var newMax = Math.min(100, user_max_limit);
            $("#concurrency").slider("option", "max", newMax);
        }
        else {
            chrome.storage.local.get('max_record_limit', function (data) {
                $("#concurrency").slider("option", "max", data['max_record_limit']);
            });
        }
        //$("#concurrency").slider("option", "max", DEFAULT_CONCURRENCY_MAX);
        $("#time-distribution").slider("option", "value", "0");
        autoTimeDistribution(0);
        updateLoadLabel(1);

        $("#concurrency-textfield").val(0);
        chrome.storage.local.set({
            'location': default_location
        });
        document.getElementById("load-origin").disabled = false;
        document.getElementById("follow-name").disabled = false;
        $('#user-agents-list').val("Default");
        initFollowMeOptions();

        options.top_level = true;
        options.cookie = false;
        options.cache = true;
        options.options = false;
        options.regex_include = 'http://*/*, https://*/*';
        options.regex_follow_input = '';
        options.useragent = 'Default';
        chrome.storage.local.set({
            'options': options
        });

        localStorage.setItem("name", "");
        localStorage.setItem("jmxname", "");
        document.getElementById("name").value = name_default;
        document.getElementById("top_level").checked = options.top_level;
        document.getElementById("regex_include").value = options.regex_include;
        document.getElementById("regex_follow_input").value = options.regex_follow_input;
        document.getElementById("cookie").checked = options.cookie;
        document.getElementById("cache").checked = options.cache;
        document.getElementById("options").checked = options.options;

        initRecordInterface();

        var status = document.getElementById("status");
        status.innerHTML = "Options were reset.";
    });
}

function pauseRecording() {
    op = 'pause';
    chrome.extension.sendRequest({
        type: 'pause_traffic'
    }, function (data) {

        if (start_recording_mode == 'mode-record') {
            chrome.storage.local.set({
                'start_recording_mode': 'mode-record'
            });
            enableBtn("record");
        } else {
            enableBtn("follow-record");
            disableBtn("record");

            start_recording_mode = 'mode-follow';
            chrome.storage.local.set({
                'start_recording_mode': 'mode-follow'
            });
        }

        disableBtn("pause");
        //enableBtn("reset");
        disableBtn("follow-pause");
        //enableBtn("follow-reset");

        var status = document.getElementById("status");
        status.innerHTML = "Recording paused!";
    });
}

function stopRecording() {
    $('#load-origin').prop('disabled', false);
    $('#user-agents-list').prop('disabled', false);
    $('#top_level').prop('disabled', false);
    $('#cache').prop('disabled', false);
    $('#cookie').prop('disabled', false);
    op = 'stopped';
    chrome.extension.sendRequest({
        type: 'stop_traffic'
    }, function (data) {
        if (mode == "mode-follow") {
            disableBtn("follow-pause");
            disableBtn("follow-stop");
            enableBtn("follow-record");
            enableBtn("follow-reset");

            document.getElementById("load-origin").disabled = false;
            document.getElementById("follow-name").disabled = false;
            //getTestsAndUserLimits();
            $("#concurrency").slider("option", "max", localStorage.getItem("real_max_follow_limit"));
            $('#overlay').remove();
        } else {
            disableBtn("pause");
            disableBtn("stop");
            enableBtn("record");
            enableBtn("reset");
        }

        if (start_recording_mode != 'mode-record') {
            // mode-follow
            disableBtn("follow-pause");
            disableBtn("follow-stop");
            enableBtn("follow-record");
            enableBtn("follow-reset");

            document.getElementById("load-origin").disabled = false;
            document.getElementById("follow-name").disabled = false;
            $("#concurrency").slider("option", "max", localStorage.getItem("real_max_follow_limit"));
            $('#overlay').remove();

            // mode-record
            disableBtn("pause");
            disableBtn("stop");
            enableBtn("record");
            enableBtn("reset");
        }

        chrome.extension.sendRequest({
            type: 'traffic_exists'
        }, function (exists) {
            if (exists) {
                if (!localStorage.getItem("name")) {
                    // If name is empty
                    chrome.extension.sendRequest({
                        type: 'get_status'
                    }, function (data) {
                        op = data.op;
                        var timeString = new Date().toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1");
                        var H = +timeString.substr(0, 2);
                        var h = H % 12 || 12;
                        var ampm = H < 12 ? " AM" : " PM";
                        timeString = h + timeString.substr(2, 6) + ampm;
                        var current_time = $.datepicker.formatDate('mm/dd/y', new Date());
                        document.getElementById("name").value = "RECORD " + current_time + " " + timeString;
                        localStorage.setItem("name", document.getElementById("name").value);
                        localStorage.setItem("jmxname", document.getElementById("name").value);

                        /*chrome.extension.sendRequest({
                         type: 'get_first_url'
                         }, function (first) {
                         var first_url = first.label;

                         });*/
                    });
                }
                // Enable edit button if there is data to edit
                enableBtn("edit");

                // The upload button should be enabled only if a. you are logged in b.
                // you are in stop mode c. there is something to upload d. the name is
                // full
                if (isLogged()) {
                    enableBtn("upload");
                    enableBtn("upload-jmx");
                }
            }
        });

        chrome.extension.sendRequest({
            type: 'traffic_exists_follow'
        }, function (exists) {
            if (exists) {
                enableBtn("follow-upload-jmx");
                enableBtn("follow-report");
            }
        });

        start_recording_mode = '';
        chrome.storage.local.set({
            'start_recording_mode': ''
        });

        var status = document.getElementById("status");
        if (mode == "mode-follow") {
            status.innerHTML = "FollowMe test stopped!";
        }
        else {
            status.innerHTML = "Recording stopped!";
        }
    });
}

function editData() {
    chrome.tabs.create({
        url: "editor.html"
    });
}

function uploadData() {
    var location_element = document.getElementById("load-origin");
    var location = location_element.options[location_element.selectedIndex].value;
    chrome.storage.local.set({
        'location': location
    });

    document.getElementById("advanced-options-fieldset").className = '';
    document.getElementById("advanced-options").style.display = 'none';

    options.regex_include = document.getElementById("regex_include").value;
    options.regex_follow_input = document.getElementById("regex_follow_input").value;
    options.top_level = document.getElementById("top_level").checked;
    options.cookie = document.getElementById("cookie").checked;
    options.cache = document.getElementById("cache").checked;
    options.options = document.getElementById("options").checked;
    chrome.storage.local.set({
        'options': options
    });
    chrome.extension.sendRequest({
        type: 'upload_traffic'
    }, function (data) {
        //var status = document.getElementById("status");
        //status.innerHTML = "<img src='../images/upload.gif'/>";
    });
    /*if (mode == 'mode-follow') {
     chrome.extension.sendRequest({
     type: 'upload_traffic_follow'
     }, function (data) {
     var status = document.getElementById("status");
     status.innerHTML = "<img src='../images/upload.gif'/>";
     });
     } else {
     chrome.extension.sendRequest({
     type: 'upload_traffic'
     }, function (data) {
     var status = document.getElementById("status");
     status.innerHTML = "<img src='../images/upload.gif'/>";
     });
     }*/
}

function changeUserAgent() {
    options.useragent = this.value;
    chrome.storage.local.set({
        'options': options
    });

    chrome.extension.sendRequest({
        type: 'change_useragent'
    }, function (data) {
        var status = document.getElementById("status");
        status.innerHTML = "<img src='../images/upload.gif'/>";
    });
}

function exportJmeter() {
    chrome.storage.local.get('mode', function (data) {
        if (data.mode == 'mode-follow') {
            chrome.extension.sendRequest({
                type: 'export_jmeter_follow'
            }, function (data) {
            });
        } else {
            chrome.extension.sendRequest({
                type: 'export_jmeter'
            }, function (data) {
            });
        }
    });
}

function startFollow() {
    var status = document.getElementById("status");
    saveAdvancedOptions();
    localStorage.setItem("jmxname", $('#follow-name').val());
    if (op != 'pause') {
        op = 'waiting';
        status.innerHTML = "Starting test...";
        // This is new follow me
        disableBtn("follow-report");
        disableBtn("follow-upload-jmx");

        start_recording_mode = mode;
        chrome.storage.local.set({
            'start_recording_mode': mode
        });

        // While the test is running the user can change the concurrency level to
        // any value from ZERO to the pre chosen max concurrency level.
        var concurrency = localStorage.getItem("concurrency");
        chrome.storage.local.set({
            'max_concurrent_users': concurrency
        });
        $("#concurrency").slider("option", "max", concurrency);

        // Options
        var follow_name = document.getElementById("follow-name").value;
        test_id = null;
        availableTests.forEach(function (test_name, index) {
            if (test_name == follow_name) {
                test_id = index;
            }
        });

        chrome.storage.local.set({
            'test_id': test_id
        });

        if (document.getElementById("follow-name").value == name_default) {
            follow_name = 'Follow Me ' + getDateTime();
            document.getElementById("follow-name").value = follow_name;
        }

        chrome.storage.local.set({
            'test_name': follow_name
        });
        var location_element = document.getElementById("load-origin");
        var location = location_element.options[location_element.selectedIndex].value;
        chrome.storage.local.set({
            'location': location
        });

        // The full interface should be disable until test is ready. Only the stop
        // button can be available to use
        // disableInterface();
    } else {
        // pause
        disableBtn("follow-record");
        enableBtn("follow-pause");
        enableBtn("pause");
    }

    disableBtn("follow-reset");
    disableBtn("reset");
    status.innerHTML = "";
    enableBtn("stop");

    chrome.extension.sendRequest({
        type: 'follow_traffic'
    }, function (data) {
    });

}

function viewReport() {

    if (!oldapi) {
        chrome.storage.local.get('session_id', function (items) {
            var session_id = items.session_id;
            if (session_id) {
                chrome.tabs.create({
                    url: server_url + "/app/#reports/" + session_id + "/summary"
                });
            }
        });
    }
    else {
        chrome.storage.local.get('test_id', function (items) {
            var test_id = items.test_id;
            if (test_id) {
                chrome.tabs.create({
                    url: server_url + "/node/" + test_id + "/gjtl"
                });
            }
        });
    }

}

function expandOptions() {
    if (document.getElementById("advanced-options-fieldset").className == 'opened') {
        $('.openclose').attr('id', 'closed');
        document.getElementById("advanced-options-fieldset").className = '';
        document.getElementById("advanced-options").style.display = 'none';
    } else {
        $('.openclose').attr('id', 'opened');
        document.getElementById("advanced-options-fieldset").className = 'opened';
        document.getElementById("advanced-options").style.display = 'block';
    }
}

function setUIForLoggedUser(username) {
    var server_path = '';
    if (!oldapi) {
        server_path = '/app';
    } else {
        server_path = '/cloud/testing/load/home';
    }
    document.getElementById("sign-block").innerHTML = "<div class='welcome'>Hi <a href='" + server_url + server_path + "' target='_blank'>" + username
    + "</a> <a class='logout' href='" + server_url + "/logout' target='_blank'>[x]</a></div>";
    $(".logout").click(function () {
        resetRecording();
    });
    localStorage.setItem("logged", true);
    localStorage.setItem("username", username);

    if (document.getElementById("options").checked) {
        document.getElementById("upload").title = "Adjust your properties and run tests from the cloud. The domains filter list must be completed before you click this button.";
        document.getElementById("upload-off").title = "Please log in or sign up to continue.";
    } else {
        document.getElementById("upload").title = "Click to run from the cloud now.";
        document.getElementById("upload-off").title = "Click to run from the cloud now.";
        document.getElementById("follow-record-off").title = "Adjust your properties and run tests from the cloud. The domains filter list must be completed before you click this button.";
    }
    if (document.getElementById("follow-name").value != ""
        && document.getElementById("regex_follow_input").value != ""
        && op == 'stopped') {
        enableBtn("follow-record");
    }

    chrome.extension.sendRequest({
        type: 'get_status'
    }, function (data) {
        op = data.op;
        chrome.extension.sendRequest({
            type: 'trafic_exists'
        }, function (exists) {
            if (exists && op == "stopped" && localStorage.getItem("name")
                && localStorage.getItem("name") != "") {
                if (isLogged()) {
                    enableBtn("upload");
                }
                enableBtn("upload-jmx");
            }
        });
    });
}

function toggleMode() {
    var keyToGet;
    if (mode == "mode-follow") {
        keyToGet = 'max_follow_limit';
        $(".time-distribution-wrapper").show();
        $("#follow-wrapper").show();
        $("#record-wrapper").hide();
        $('.onoffswitch-checkbox').val('mode-follow');
        $('.options-wrapper').hide();
        $('.regex-wrapper').hide();
        //$("#add-concurrency").show();
        $(".top-level-wrapper").hide();
        $('.regex-follow-wrapper').show();
        $('.mode-record').attr('id', 'not-current');
        $('.mode-follow').attr('id', 'current');
        document.getElementById('mode').value = 'mode-record';
        $('.onoffswitch-checkbox').attr('checked', 'checked');
    } else {
        keyToGet = 'max_record_limit';
        $("#record-wrapper").show();
        $(".time-distribution-wrapper").hide();
        $(".top-level-wrapper").show();
        $("#follow-wrapper").hide();
        $("#add-concurrency").hide();
        //$('#mode-record').prop('checked', true);
        $('.onoffswitch-checkbox').val('mode-record');
        $('.options-wrapper').show();
        $('.regex-follow-wrapper').hide();
        $('.regex-wrapper').show();
        $('.mode-record').attr('id', 'current');
        $('.mode-follow').attr('id', 'not-current');
        document.getElementById('mode').value = 'mode-follow';
        $('.onoffswitch-checkbox').removeAttr('checked');
    }

    //get max values for concurrency by mode from storage
    chrome.storage.local.get(keyToGet, function (data) {
        data = data || {};
        var newMax;
        var $slider = $('#concurrency');
        var curValue = $slider.slider('option', 'value');

        if (op != 'stopped' && mode == 'mode-follow') {
            chrome.storage.local.get('max_concurrent_users', function (items) {
                //Make sure max concurrenct is not breached in active followme mode
                $slider.slider("option", "max", items.max_concurrent_users);
                var newValue = Math.min(curValue, items.max_concurrent_users);
                $slider.slider("option", "value", newValue);
                $("#concurrency-display-textfield").value = newValue;
                localStorage.setItem("concurrency", newValue);
            });
            return;
        }
        else if (op == 'stopped' && mode == 'mode-follow' && isLogged()) {
            var user_max_limit = localStorage.getItem("real_max_follow_limit");
            newMax = Math.min(100, user_max_limit);
            if (curValue <= 1000 && curValue > 100) {
                newMax = Math.min(1000, user_max_limit);
            }
            else if (curValue <= 10000 && curValue > 1000) {
                newMax = Math.min(10000, user_max_limit);
            }
            else if (curValue <= 50000 && curValue > 10000) {
                newMax = Math.min(50000, user_max_limit);
            }
            else if (curValue <= 100000 && curValue > 50000) {
                newMax = Math.min(100000, user_max_limit);
            }
        }
        else if (!isLogged() && mode == 'mode-follow') {
            newMax = DEFAULT_CONCURRENCY_MAX;
        }
        else {
            newMax = data[keyToGet];
            if (!newMax) {
                return;
            }
        }

        var newValue = Math.min(curValue, newMax);
        //update slider max value according to new mode
        $slider.slider("option", "max", newMax);
        $slider.slider("option", "value", newValue);
        //Show + button only if user can add more
        if (mode == 'mode-follow' && newMax != user_max_limit && op == 'stopped' && isLogged()) {
            $("#add-concurrency").show();
        }
        else {
            $("#add-concurrency").hide();
        }
        updateSliderLabel(newValue);

        if (localStorage.getItem("time-distribution") == '0') {
            autoTimeDistribution(curValue);
        }
        else {
            $("#time-distribution-display-textfield").val(localStorage.getItem("time-distribution"));
            $('#time-distribution').slider("option", "value", localStorage.getItem("time-distribution"));
        }
    });
}

function getTestsAndUserLimits() {
    //Check to see if this user is V3 user
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status == 200) {
                var params = JSON.parse(xmlhttp.response);
                //"Features" is the new and more correct approach looking forward, but as if
                // today we do not have feature indicating that user is set to use v3 by default.
                // The only way to detect this is by using v3default role
                if ($.inArray("v3default", params.roles) !== -1) {
                    //Optional - users with v3 default always will navigate to v3.
                    //localStorage["isV3User"] = true;
                    localStorage["oldapi"] = false;
                    oldapi = false;
                    //Reload options
                    chrome.extension.sendMessage({
                        op: "reloadoptions"
                    });
                }

                if (!oldapi) {
                    //V3 user
                    $(".welcome a").attr("href", server_url + "/app/");
                    var concurrency = params.plan.concurrency;
                    setUIForLoggedUser(params.name);
                    localStorage.setItem("duration", params.plan.duration);
                    var real_max_follow_limit = Math.min(concurrency, MAX_FOLLOW_ME_LIMIT);
                    localStorage.setItem('real_max_follow_limit', real_max_follow_limit);
                    // Set geolocations
                    $('#load-origin').html('');
                    params.locations.forEach(function (location) {
                        $('#load-origin').append(
                            $('<option>').text(location.title).attr('value', location.id));
                    });
                    chrome.storage.local.get('location', function (items) {
                        if (items.location) {
                            $('#load-origin').val(items.location);
                        } else {
                            $('#load-origin').val(default_location);
                        }
                    });
                    chrome.extension.sendRequest({
                            type: 'get_status'
                        },
                        function (data) {
                            op = data.op;
                            if (op != 'stopped' && (mode == 'mode-follow' || (mode == 'mode-record' && start_recording_mode == 'mode-follow'))) {
                                // max concurent users is max number selected
                                chrome.storage.local.get('max_concurrent_users', function (items) {
                                    max_concurrent_users = items.max_concurrent_users;
                                });
                            }
                            else {
                                var _limits = {
                                    max_follow_limit: Math.min(params.plan.concurrency, MAX_FOLLOW_ME_LIMIT),
                                    max_record_limit: Math.min(params.plan.concurrency, MAX_RECORDING_LIMIT)
                                };
                                chrome.storage.local.set(_limits);
                                max_concurrent_users = (mode === 'mode-follow') ? _limits.max_follow_limit : _limits.max_record_limit;
                                if (mode === 'mode-follow' && max_concurrent_users < DEFAULT_CONCURRENCY_MAX) {
                                    $("#concurrency").slider("option", "max", max_concurrent_users);
                                }

                                if (localStorage.getItem("concurrency") > max_concurrent_users) {
                                    var user_max_concurrency = localStorage.getItem("real_max_follow_limit");
                                    var current_conc = localStorage.getItem("concurrency");
                                    //@todo: use Math.min
                                    if (current_conc > 50 && current_conc <= 100) {
                                        max_con_users = 100;
                                    }
                                    else if (current_conc <= 1000 && current_conc > 100) {
                                        max_con_users = 1000;
                                    }
                                    else if (current_conc <= 1000 && current_conc > 100) {
                                        max_con_users = 10000;
                                    }
                                    else if (current_conc <= 10000 && current_conc > 1000) {
                                        max_con_users = 50000;
                                    }
                                    else if (current_conc <= 50000 && current_conc > 10000) {
                                        max_con_users = 100000;
                                    }
                                    else {
                                        max_con_users = user_max_concurrency;
                                    }

                                    if (max_con_users > user_max_concurrency) {
                                        max_con_users = user_max_concurrency;
                                    }
                                    $("#concurrency").slider("option", "max", max_con_users);

                                    if (user_max_concurrency == max_con_users) {
                                        //Hide + button if user can't add more
                                        $("#add-concurrency").hide();
                                    }
                                }
                            }
                        });
                    var xmlhttp2 = new XMLHttpRequest();
                    xmlhttp2.onreadystatechange = function () {
                        if (xmlhttp2.readyState == 4) {
                            if (xmlhttp2.status == 200) {
                                availableTests = new Array();
                                var availableTags = new Array();
                                var response = JSON.parse(xmlhttp2.response);
                                response.result.forEach(function (entry) {
                                    var type = entry.configuration.type;
                                    if (type == 'followme') {
                                        availableTags.push(entry.name + " (id: " + entry.id + ")");
                                        availableTests[entry.id] = entry.name + " (id: " + entry.id + ")";
                                    }
                                });
                                $("#follow-name").autocomplete({
                                    source: availableTags
                                });
                                chrome.storage.local.get('test_id', function (items) {
                                    if (items.id) {
                                        // If there is test id make sure we are using it instead of name
                                        // only
                                        $("#follow-name").val(availableTests[items.id]);
                                    }
                                });
                            }
                        }
                    }

                    xmlhttp2.open("GET", server_url + "/api/latest/tests?" + API_client_identification(), true);
                    xmlhttp2.setRequestHeader('Content-type', 'application/json');
                    xmlhttp2.send();
                    toggleMode();
                }
                else {
                    //Using Old API
                    getTestsAndUserLimitsOld();
                }
            } else {
                localStorage.setItem("logged", false);
                disableBtn("upload");
                disableBtn("upload-jmx");
                disableBtn("follow-upload-jmx");
                disableBtn("follow-report");
                disableBtn("follow-record");
                document.getElementById("upload-off").title = "Please log in or sign up to continue.";
                document.getElementById("follow-record-off").title = "Please log in or sign up to continue.";
                document.getElementById("upload-jmx-off").title = "Please log in or sign up to continue.";
                return;
                localStorage.setItem("logged", false);
            }
        }
    }
    xmlhttp.open("GET", server_url + "/api/latest/user", true);
    xmlhttp.send();
}

function getTestsAndUserLimitsOld() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status != 200) {
                console.log("Not logged");
                //Not logged in
                localStorage.setItem("logged", false);
                disableBtn("upload");
                disableBtn("upload-jmx");
                disableBtn("follow-upload-jmx");
                disableBtn("follow-report");
                disableBtn("follow-record");
                document.getElementById("upload-off").title = "Please log in or sign up to continue.";
                document.getElementById("follow-record-off").title = "Please log in or sign up to continue.";
                document.getElementById("upload-jmx-off").title = "Please log in or sign up to continue.";
                return;
            } else {
                var user = JSON.parse(xmlhttp.response);
                if (user && user.user) {
                    setUIForLoggedUser(user.user.username);
                    var real_max_follow_limit = Math.min(user.user.max_users_limit, MAX_FOLLOW_ME_LIMIT);
                    localStorage.setItem('real_max_follow_limit', real_max_follow_limit);
                    // Set geolocations
                    $('#load-origin').html('');
                    user.user.locations
                        .forEach(function (location) {
                            $('#load-origin').append(
                                $('<option>').text(location.title).attr('value', location.id));
                        });
                    chrome.storage.local.get('location', function (items) {
                        if (items.location) {
                            $('#load-origin').val(items.location);
                        } else {
                            $('#load-origin').val(default_location);
                        }
                    });

                    chrome.extension.sendRequest({
                            type: 'get_status'
                        },
                        function (data) {
                            op = data.op;
                            if (op != 'stopped' && (mode == 'mode-follow' || (mode == 'mode-record' && start_recording_mode == 'mode-follow'))) {
                                // max concurent users is max number selected
                                chrome.storage.local.get('max_concurrent_users', function (items) {
                                    max_concurrent_users = items.max_concurrent_users;
                                });
                            }
                            else {
                                var _limits = {
                                    max_follow_limit: Math.min(user.user.max_users_limit, MAX_FOLLOW_ME_LIMIT),
                                    max_record_limit: Math.min(user.user.max_users_limit, MAX_RECORDING_LIMIT)
                                };
                                chrome.storage.local.set(_limits);
                                max_concurrent_users = (mode === 'mode-follow') ? _limits.max_follow_limit : _limits.max_record_limit;
                                if (mode === 'mode-follow' && max_concurrent_users < DEFAULT_CONCURRENCY_MAX) {
                                    $("#concurrency").slider("option", "max", max_concurrent_users);
                                }
                                if (localStorage.getItem("concurrency") > max_concurrent_users) {
                                    changeSliderMax();
                                }
                            }
                        });
                }
                if (user && user.tests) {
                    availableTests = new Array();
                    var availableTags = new Array();
                    user.tests.forEach(function (entry) {
                        availableTags.push(entry.title + " (id: " + entry.test_id + ")");
                        availableTests[entry.test_id] = entry.title + " (id: " + entry.test_id + ")";
                    });
                    $("#follow-name").autocomplete({
                        source: availableTags
                    });
                    chrome.storage.local.get('test_id', function (items) {
                        if (items.test_id) {
                            // If there is test id make sure we are using it instead of name
                            // only
                            $("#follow-name").val(availableTests[items.test_id]);
                        }
                    });
                }

            }
        }
        toggleMode();
    }
    xmlhttp.open("GET", server_url + "/api/followme/tests?user=true&" + API_client_identification(), true);
    xmlhttp.setRequestHeader('Content-type', 'application/json');
    xmlhttp.send();
}

/*
 * function disableInterface() { //The full interface should be disabled until
 * test is ready. Only the stop button can be available to use
 * enableBtn("follow-stop"); disableBtn("follow-record");
 * disableBtn("follow-reset"); disableBtn("follow-report");
 * document.getElementById("follow-name").disabled = true;
 * $('.test-options').append('<div id="overlay"></div>'); }
 */
function initFollowMeInterface() {
    if (isLogged() && document.getElementById("follow-name").value != "" && document.getElementById("regex_follow_input").value != "") {
        enableBtn("follow-record");
    } else {
        disableBtn("follow-record");
    }
    enableBtn("follow-reset");
    disableBtn("follow-stop");
    disableBtn("follow-pause");
    disableBtn("follow-upload-jmx");
    disableBtn("follow-report");
}

function changeSliderMax() {
    var user_max_concurrency = localStorage.getItem("real_max_follow_limit");
    var current_conc = localStorage.getItem("concurrency");
//@todo: use Math.min
    if (current_conc <= 100) {
        max_concurrent_users = 1000;
    }
    else if (current_conc <= 1000 && current_conc > 100) {
        max_concurrent_users = 10000;
    }
    else if (current_conc <= 10000 && current_conc > 1000) {
        max_concurrent_users = 50000;
    }
    else if (current_conc <= 50000 && current_conc > 10000) {
        max_concurrent_users = 100000;
    }
    else {
        max_concurrent_users = user_max_concurrency;
    }

    if (max_concurrent_users > user_max_concurrency) {
        max_concurrent_users = user_max_concurrency;
    }
    $("#concurrency").slider("option", "max", max_concurrent_users);

    if (user_max_concurrency == max_concurrent_users) {
        //Hide + button if user can't add more
        $("#add-concurrency").hide();
    }
}

function initRecordInterface() {
    enableBtn("record");
    enableBtn("reset");
    disableBtn("pause");
    disableBtn("stop");
    disableBtn("edit");
    disableBtn("upload");
    disableBtn("upload-jmx");
}

function initFollowMeOptions() {
    chrome.storage.local.get(null, function (all) {
        if (all.test_name) {
            document.getElementById("follow-name").value = all.test_name;
        } else {
            document.getElementById("follow-name").value = name_default;
        }

        initFollowMeInterface();
        var concurrency = localStorage.getItem("concurrency");
        $("#concurrency").slider("option", "value", concurrency);
        document.getElementById("concurrency-display-textfield").value = concurrency;
        if (all.location) {
            $('#load-origin').val(all.location);
        } else {
            $('#load-origin').val(default_location);
        }
    });
}

function saveAdvancedOptions() {
    //Set options
    options.regex_include = document.getElementById("regex_include").value;
    options.regex_follow_input = document.getElementById("regex_follow_input").value;
    options.top_level = document.getElementById("top_level").checked;
    options.cookie = document.getElementById("cookie").checked;
    options.cache = document.getElementById("cache").checked;
    options.options = document.getElementById("options").checked;
    chrome.storage.local.set({
        'options': options
    });
}


function getDateTime() {
    var now = new Date();
    var year = now.getFullYear() - 2000;
    var month = now.getMonth() + 1;
    var day = now.getDate();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    if (month.toString().length == 1) {
        var month = '0' + month;
    }
    if (day.toString().length == 1) {
        var day = '0' + day;
    }
    if (hour.toString().length == 1) {
        var hour = '0' + hour;
    }
    if (minute.toString().length == 1) {
        var minute = '0' + minute;
    }
    if (second.toString().length == 1) {
        var second = '0' + second;
    }
    var dateTime = month + '/' + day + '/' + year + ' ' + ((hour < 10) ? '0' : '' + ((hour > 12) ? (hour - 12) : hour)) + ':' + minute + ':' + second + ' ' + ((hour > 12) ? 'PM' : 'AM');

    return dateTime;
}

function autoTimeDistribution(concurrency) {
    var time_auto = '10';
    if (concurrency <= 1000 && concurrency > 100) {
        time_auto = '20';
    }
    else if (concurrency <= 10000 && concurrency > 1000) {
        time_auto = '60';
    }
    else if (concurrency > 10000) {
        time_auto = '300';
    }
    $('#time-distribution-display-textfield').val("AUTO (" + time_auto + ")");
    localStorage.setItem('auto_time_distribution', time_auto);
}

function updateLoadLabel(concurrency) {
    if (concurrency <= 100) {
        $(".concurrency-wrapper #concurrency").css("background-color", "#C8EB1B");
        $(".load").text('Light load');
    }
    else if (concurrency > 100 && concurrency <= 1000) {
        $(".concurrency-wrapper #concurrency").css("background-color", "#FFE26C");
        $(".load").text('Moderate load');
    }
    else if (concurrency > 1000 && concurrency <= 10000) {
        $(".concurrency-wrapper #concurrency").css("background-color", "#FFCD00");
        $(".load").text('High load');
    }
    else if (concurrency > 10000) {
        $(".concurrency-wrapper #concurrency").css("background-color", "#FF5252");
        $(".load").text('Extreme load');
    }
}

function API_client_identification() {
    return "_clientId=BE_CHROME&_clientVersion=​" + manifest.version;
}
