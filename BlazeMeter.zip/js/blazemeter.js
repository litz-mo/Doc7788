if (!localStorage.getItem("server")) {
    localStorage.setItem("server", "https://a.blazemeter.com");
}
var server_url = localStorage.getItem("server");

// Stores all recorded traffic
var traffic = new Object();
var traffic_follow = new Object();

var body = new Object();
var json = null;

var btnstate = true;
var op = "stopped";
var options = new Object();
//var parse_url = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/;
var parser = document.createElement('a');
var retries = 5;
var debug = false;
var counter = 0;
var counter_follow = 0;
var clearRunning = false;
var jmx_data_url = "";
var modalIsOpened = false;
var cache = false;
var cookie = false;
var incognito = chrome.extension.inIncognitoContext;
var testcontinue = false;
var top_level = true;
var dismissed = false;

var record_test_id = null;

var mode;
chrome.storage.local.get('mode', function (data) {
    if (data.mode) {
        mode = data.mode;
    } else {
        mode = 'mode-record';
    }
});

var useragent = false;
var useragents = new Object();

// user agent parse json and set from storage
jQuery.getJSON("js/useragentslist.js", function (data) {
    jQuery.each(data.UserAgentList, function (key, value) {
        jQuery.each(value.UserAgents, function (key1, value1) {
            useragents[value1.Id] = value1.UserAgent;
        });
    });

    chrome.storage.local.set({
        'useragentlist': useragents
    });

    return false;
});

// var step = 1;
var test_id = null;
var waiting = false;

var session_id = null;

// Run test progress bar
var progress_bar = 0;

var gPendingCallbacks = [];
var bkg = chrome.extension.getBackgroundPage();

var response = new Object();

var continue_old_test = false;
var continue_old_test_state = 'none';

if (localStorage.getItem("debug") == 'true') {
    console.log("Debug mode");
    debug = true;
}

if (localStorage.getItem("oldapi") == 'true') {
    console.log("Using Old API");
    oldapi = true;
}
else {
    oldapi = false;
}

var main_frame_tabIds = [];

recordBlink();

function startRecording() {
    chrome.storage.local.get('options', function (items) {

        options = items.options;
        cache = options.cache;
        cookie = options.cookie;
        //Save top_level as global var so it can be checked while we capture recordings
        top_level = options.top_level;
        body = new Object();
        if (cache) {
            clearCache();
        }

        if (items.options.useragent) {
            useragent = items.options.useragent;
        }
        var RequestFilter = {};

        if (!options.regex_include || op == 'follow') {
            var match_patterns = [ 'http://*/*', 'https://*/*' ];
        } else {
            var match_patterns = options.regex_include.split(", ");
        }

        RequestFilter.urls = match_patterns;
        /*var validurl = false;
        for (i = 0; i < RequestFilter.urls.length; ++i) {
            var myVariable = RequestFilter.urls[i];
            if(/^([a-z]([a-z]|\d|\+|-|\.)*):(\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?((\[(|(v[\da-f]{1,}\.(([a-z]|\d|-|\.|_|~)|[!\$&'\(\)\*\+,;=]|:)+))\])|((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=])*)(:\d*)?)(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*|(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)|((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)|((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)){0})(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(myVariable)) {
            	validurl = true;
            } else {
            	validurl = false;
            }
        }*/
        // top level traffic only
        //if(validurl == true) {
        	chrome.extension.sendMessage({
                op: "continue_recording"
            });
            if (op == 'follow' || options.top_level) {
                // Record main frame and xmlhttprequests (ajax)
                RequestFilter.types = [ 'main_frame', 'xmlhttprequest' ];
            }
            // listeners
            chrome.webRequest.onBeforeSendHeaders.addListener(onBeforeSendHeaders, RequestFilter, [
                "blocking", "requestHeaders" ]);

            chrome.webRequest.onBeforeRequest.addListener(onBeforeRequest, RequestFilter,
                [ "requestBody" ]);
            // We use onSendHeaders to collect send headers
            chrome.webRequest.onSendHeaders.addListener(onSendHeaders, RequestFilter,
                [ "requestHeaders" ]);
            delete (RequestFilter.types);
            chrome.webRequest.onAuthRequired.addListener(handleAuthRequest, RequestFilter, [
                "asyncBlocking", "responseHeaders" ]);
        /*} else {
            chrome.extension.sendMessage({
                op: "stop_recording"
            });
        }*/
    });
}

function stopRecording() {
    chrome.webRequest.onBeforeRequest.removeListener(onBeforeRequest);
    chrome.webRequest.onSendHeaders.removeListener(onSendHeaders);
    chrome.webRequest.onAuthRequired.removeListener(handleAuthRequest);
    chrome.webRequest.onBeforeSendHeaders.removeListener(onBeforeSendHeaders);

    // Convert traffic
    traffic = convertTraffic(traffic);
    traffic_follow = convertTraffic(traffic_follow);

    main_frame_tabIds = [];
}

function convertTraffic(trafficv) {
    var new_traffic = {};
    var key = '';
    for (var items in trafficv) {
        key = trafficv[items].method + ' ' + trafficv[items].url.substring(0, 130) + ' ['
            + trafficv[items].requestId + ']';
        delete trafficv[items].requestId;
        new_traffic[key] = trafficv[items];
    }
    return new_traffic;
}

function clearCache() {

    if (!clearRunning) {
        // If clear cache is enabled
        if (chrome.browsingData != undefined) {
            clearRunning = true;
            var oneWeekAgo = (new Date()).getTime() - 604800000;
            // Chrome 19:
            chrome.browsingData.removeCache({
                "since": oneWeekAgo
            }, function () {

                clearRunning = false;
            });
        } else {
            // Chrome < 19
            console.log("Your browser does not support 'chrome.browsingData.removeCache'.");
        }
    }
}

function handleAuthRequest(info, callback) {
    if (mode == "mode-record" || (mode == "mode-follow" && checkRegexFollow(info))) {
        gPendingCallbacks.push(callback);
        processPendingCallbacks(info);
    }
    else {
        //use asyncBlocking and call callback without parameters to return to the browser and seek auth from user
        callback();
    }
}

function processPendingCallbacks(info) {
    var authCredentials = {
        "authCredentials": {
            "username": null,
            "password": null
        }
    };
    modalIsOpened = true;
    authCredentials = window.showModalDialog("httpauth-dialog.html", authCredentials,
        "chrome,centerscreen");
    modalIsOpened = false;

    if (!authCredentials) {
        authCredentials = {
            "authCredentials": {
                "username": null,
                "password": null
            }
        }
    }

    var key = info.method + info.requestId;
    data = new Object();

    data.url = data.label = info.url;
    data.method = info.method;
    data.requestId = info.requestId;
    data.timestamp = Math.round(info.timeStamp); // in ns??
    // 1372431305768.1938 we
    // convert into milliseconds
    data.headers = info.responseHeaders;
    data.authentication = authCredentials["authCredentials"];

    for (var index in data.headers) {
        if (data.headers[index].name == 'Cookie') {
            if (!cookie) {
                // Don't record cookies
                data.headers.splice(index, 1);
                console.log("Cookie deleted");
            } else {
                // Store cookie in the
                var cookie_array = data.headers[index].value.split("; ");
                data.cookies = cookie_array;
            }
            break;
        }
    }

    if (authCredentials.authCredentials.username !== null
        && authCredentials.authCredentials.password !== null) {

        var headerAuthorization = {
            "name": "Autorization",
            "value": "Basic "
                + window.btoa(authCredentials.authCredentials.username + ":"
                + authCredentials.authCredentials.password)
        };

        var lastKey = Object.keys(data.headers).sort().reverse()[0];
        var nextKey = parseInt(lastKey) + 1;
        data.headers[nextKey] = headerAuthorization;

        var callback = gPendingCallbacks.pop();
        callback(authCredentials);

        if (mode == "mode-record") {
            if (!traffic[key]) {
                counter++;
                drawBadgeDynamic();
            }
            traffic[key] = data;
        } else {
            if (!traffic_follow[key]) {
                counter++;
                drawBadgeDynamic();
            }
            traffic_follow[key] = data;
            counter_follow++;

            // @todo: filter this requests otherwise we will have loop
            if(!oldapi) {
                setProperty(session_id, counter_follow, traffic_follow[key],
                        localStorage.getItem("concurrency"), localStorage.getItem("time-distribution"));
            } else {
                setProperty(test_id, counter_follow, window.btoa(JSON.stringify(traffic_follow[key])),
                        localStorage.getItem("concurrency"), localStorage.getItem("time-distribution"));
            }
        }

        if (debug) {
            console.log("Captured: ");
            console.log(traffic[key]);
        }
    }
}

function onBeforeSendHeaders(info) {
    if (useragent && useragent != "Default") {
        // Replace the User-Agent header
        var headers = info.requestHeaders;
        headers.forEach(function (header, i) {
            if (header.name.toLowerCase() == 'user-agent') {
                header.value = useragents[useragent];
            }
        });
        return {
            requestHeaders: headers
        };
    }
}

function onBeforeRequest(info) {
    if (info.requestBody) {
        var post_data = '';
        if (info.requestBody.formData) {
            // If the request method is POST and the body is a sequence of key-value
            // pairs encoded in UTF8,
            // encoded as either multipart/form-data, or
            // application/x-www-form-urlencoded
            post_data = info.requestBody.formData;
            // switch array to string
            for (var index in post_data) {
                post_data[index] = post_data[index].toString();
            }
        } else {
            // If the request method is PUT or POST, and the body is not already
            // parsed in formData, then the
            // unparsed request body elements are contained in this array.
            post_data = new Array();

            info.requestBody.raw.forEach(function (raw) {

                if (raw.bytes) {
                    var body_string = '';
                    bytes = new Uint8Array(raw.bytes), length = bytes.length;
                    for (var i = 0; i < length; i++) {
                        body_string += String.fromCharCode(bytes[i]);
                    }
                    post_data.push(body_string);
                } else {
                    // @todo:support for file uploads
                }
            });
        }
        var key = info.method + info.requestId;
        body[key] = post_data;
    }
}

function checkRegexFollow(info) {
    if (options.regex_follow_input != '') {
        var selected_domains = options.regex_follow_input.replace(/[ ,]+/g, ",");
        var split_selected_domains = selected_domains.split(",");
        for (i = 0; i < split_selected_domains.length; i++) {
            var matches = isFromRoot(split_selected_domains[i], info.url);
            if (matches) {
                //If domain matches
                if (main_frame_tabIds.indexOf(info.tabId) < 0) {
                    //This is main_frame push its tab id
                    main_frame_tabIds.push(info.tabId);
                }
                //One domain matches, no need to loop through rest.
                return true;
            }
        }
    }
    return false;
}

function isFromRoot(rootDomain, testURL) {
    if (typeof(testURL) === 'undefined') return false;
    parser.href = testURL;
    var get_domain_url = parser.hostname;
    console.log('get_domain_url'+get_domain_url);
    if (get_domain_url.trim() === rootDomain) return true;

    var pattern = "([\\.]+" + rootDomain + ")(?![0-9a-zA-Z\\-\\.])";
    var expression = new RegExp(pattern, "gi");
    return expression.test(get_domain_url);
}

function onSendHeaders(info) {
    if (info.tabId >= 0 && (debug || !isFromRoot('blazemeter.com', info.url))) {
        if (mode == "mode-record" || (mode == "mode-follow" && checkRegexFollow(info))) {
            if (info.type == "xmlhttprequest" && top_level && info.parentFrameId != -1) {
                //Discard AJAX/XHR requests in Top Level mode if they are not generated by standalone app like PostMan (id=-1)
                return;
            }

            if (cache) {
                clearCache();
            }
            var key = info.method + info.requestId;
            data = new Object();

            data.url = data.label = info.url;
            data.method = info.method;
            if (body[key]) {
                data.body = body[key];
            }
            data.requestId = info.requestId;
            data.timestamp = Math.round(info.timeStamp); // in ns??
            // 1372431305768.1938 we
            // convert into milliseconds
            data.headers = info.requestHeaders;

            for (var index in data.headers) {
                if (data.headers[index].name == 'Cookie') {
                    if (!cookie) {
                        // Don't record cookies
                        data.headers.splice(index, 1);
                        console.log("Cookie deleted");
                    } else {
                        // Store cookie in the
                        var cookie_array = data.headers[index].value.split("; ");
                        data.cookies = cookie_array;
                    }
                    break;
                }
            }
            if (mode == "mode-record") {
                if (!traffic[key]) {
                    // It seems that chrome produces duplicate requestId for some
                    // traffic
                    // (mainly search bar)
                    traffic[key] = data;
                    counter++;

                    drawBadgeDynamic();

                    if (debug) {
                        console.log("Captured: ");
                        console.log(traffic[key]);
                    }
                }
            } else {
                if (!traffic_follow[key]) {
                    // It seems that chrome produces duplicate requestId for some traffic
                    // (mainly search bar)
                    counter++;

                    drawBadgeDynamic();

                    traffic_follow[key] = data;
                    counter_follow++; // step

                    // @todo: filter this requests otherwise we will have loop
                    if(!oldapi) {
                        setProperty(session_id, counter_follow, traffic_follow[key],
                                localStorage.getItem("concurrency"), localStorage.getItem("time-distribution"));
                    } else {
                        setProperty(test_id, counter_follow, window.btoa(JSON.stringify(traffic_follow[key])),
                                localStorage.getItem("concurrency"), localStorage.getItem("time-distribution"));
                    }
                }

                if (debug) {
                    console.log("Captured: ");
                    console.log(traffic_follow[key]);
                }
            }
        }
    }
}

/* Listener to send stringify traffic JSON to popup script */
chrome.extension.onRequest.addListener(function (request, sender, callback) {

    if (request.type == 'pause_traffic') {
        if (modalIsOpened) {
            return;
        }
        stopRecording();
        op = 'pause';
        chrome.browserAction.setIcon({
            path: "../images/off.png"
        });
        console.log("BlazeMeter: paused recording traffic");
        callback(true);
    } else if (request.type == 'stop_traffic') {
        if (modalIsOpened) {
            return;
        }
        stopRecording();
        op = 'stopped';
        console.log("BlazeMeter: stopped recording traffic");
        chrome.storage.local.get([ 'mode', 'test_id' ], function (items) {

            if (items.mode == "mode-follow") {
                stopTest(items.test_id);
            }
        });
        callback(true);
    } else if (request.type == 'reset_traffic') {
        traffic = traffic_follow = new Object();
        counter = 0;
        counter_follow = 0;
        op = 'stopped';
        // Stop the test if mode was follow
        chrome.storage.local.get([ 'mode', 'test_id' ], function (items) {
            if (items.mode == "mode-follow" &&  localStorage.getItem("logged") !== "false") {
                stopTest(items.test_id);
            }
        });
        console.log("BlazeMeter: traffic reset");
        callback(true);
    } else if (request.type == 'start_traffic') {
        if (op == 'stopped') {
            // If traffic was stopped reset it on next start
            traffic = traffic_follow = new Object();
            counter = 0;
            counter_follow = 0;
            console.log("BlazeMeter: traffic restarted");
        }
        op = 'record';
        startRecording();
        console.log("BlazeMeter: started recording traffic");
        callback(true);
    } else if (request.type == 'dismiss_test') {
        terminateTest(test_id);
        //stopTest(test_id);
        dismissed = true;
        progress_bar = 101; // Stop the progressbar
        chrome.extension.sendMessage({
            status: "FollowMe test stopped!"
        });
        chrome.storage.local.get([ 'mode', 'test_id' ], function (items) {
            if (items.mode == "mode-follow") {
                op = 'stopped';
                chrome.extension.sendMessage({
                    op: "progressbar",
                    progress: 0,
                    followstopped: true
                });
            }
        });
        test_id = null;
        session_id = null;
        callback(true);
    } else if (request.type == 'follow_traffic') {
        if (op == 'pause') {
            op = 'follow';
            startRecording();
            console.log("BlazeMeter: started recording traffic");
            callback(true);
            return;
        } else if (op == 'stopped') {
            // If traffic was stopped reset it on next start
            traffic = traffic_follow = new Object();
            counter = 0;
            counter_follow = 0;
            /*chrome.storage.local.set({
                'test_status': "Not ready"
            });*/
            console.log("BlazeMeter: traffic restarted");
        }
        op = 'waiting';
        chrome.storage.local.get(null, function (all) {

            test_id = all.test_id;
            concurrency = localStorage.getItem("concurrency");
            //time_distribution = localStorage.getItem("time-distribution");
            geolocation = all.location;
            if (!test_id) {
                test_name = all.test_name;
                createTest(test_name, concurrency, geolocation);

            } else {
                var mode = all.mode;
                updateTest(test_id, concurrency, geolocation, mode);
                continue_old_test = true;
            }
            progress_bar = 0;
            waitUntilTestIsReady();
        });

        callback(true);
    } else if (request.type == 'get_traffic') {
        data = JSON.stringify(traffic);
        callback(data);
    } else if (request.type == 'get_first_url') {
        for (first in traffic)
            break;
        if (traffic.hasOwnProperty(first)) {
            callback(traffic[first]);
        }
    } else if (request.type == 'get_json') {
        var traffic_array = new Array();
        for (var items in traffic) {
            traffic_array.push(traffic[items]);
        }
        json = new Object();
        json.traffic = traffic_array;
        chrome.storage.local.get('options', function (items) {
            options = items.options;
            json.name = localStorage.getItem("name");
            json.regex_include = options.regex_include;
            // json.regex_exclude = options.regex_exclude;
            json.top_level = options.top_level;
            json.cookie = options.cookie;
            json = JSON.stringify(json);
            callback(json);
        });
        // callback(json);
    } else if (request.type == 'get_status') {
        data = new Object();
        // data.active = active;
        data.op = op;
        callback(data);
    } else if (request.type == 'upload_traffic') {
        dismissed = false;
        var canUpload = true;
        var upload_traffic = traffic;
        chrome.storage.local.get(null,
            function (all) {

                options = all.options;
                var selected_domains = all.selected_domains;
                if (Object.keys(selected_domains).length > 0) {
                    // Then this is step 2, user already selected domains in overlay
                    upload_traffic = {};
                    for (index in traffic) {
                        var url_label = parseURL(traffic[index].url);
                        if (selected_domains.hasOwnProperty(url_label)) {
                            upload_traffic[index] = traffic[index];
                        }
                    }
                    chrome.storage.local.set({
                        'selected_domains': {}
                    });
                } else if (options.regex_include == ''
                    || options.regex_include == 'http://*/*, https://*/*') {
                    // If Include patter is empty
                    var url_domains = getURLs(mode);
                    if (Object.keys(url_domains).length > 1) {
                        // If more than one domain in traffic, display overflow with
                        // domain
                        // selection
                        canUpload = false;
                        chrome.extension.sendMessage({
                            op: "domainoverlay",
                            domains: JSON.stringify(url_domains),
                            action: 'upload'
                        });
                    }
                }

                if (canUpload) {
                    progress_bar = 0;
                    progressBar();
                    uploadData(upload_traffic, mode);
                }
            });

        callback(true);
    } else if (request.type == 'upload_traffic_follow') {
        dismissed = false;
        var canUpload = true;
        var upload_traffic = traffic_follow;
        chrome.storage.local.get(null,
            function (all) {
                options = all.options;
                var selected_domains = all.selected_domains;
                if (Object.keys(selected_domains).length > 0) {
                    // Then this is step 2, user already selected domains in overlay
                    upload_traffic = {};
                    for (index in traffic_follow) {
                        var url_label = parseURL(traffic_follow[index].url);
                        if (selected_domains.hasOwnProperty(url_label)) {
                            upload_traffic[index] = traffic_follow[index];
                        }
                    }
                    chrome.storage.local.set({
                        'selected_domains': {}
                    });
                } else if (options.regex_include == ''
                    || options.regex_include == 'http://*/*, https://*/*') {
                    // If Include patter is empty
                    var url_domains = getURLs(mode);
                    if (Object.keys(url_domains).length > 1) {
                        // If more than one domain in traffic, display overflow with
                        // domain
                        // selection
                        canUpload = false;
                        chrome.extension.sendMessage({
                            op: "domainoverlay",
                            domains: JSON.stringify(url_domains),
                            action: 'upload'
                        });
                    }
                }

                if (canUpload) {
                    progress_bar = 0;
                    progressBar();
                    uploadData(upload_traffic, mode);
                }
            });

        callback(true);
    } else if (request.type == 'export_jmeter') {
        var canUpload = true;
        var upload_traffic = traffic;
        chrome.storage.local.get(null,
            function (all) {
                options = all.options;
                var selected_domains = all.selected_domains;
                if (Object.keys(selected_domains).length > 0) {
                    // Then this is step 2, user already selected domains in overlay
                    upload_traffic = {};
                    for (index in traffic) {
                        var url_label = parseURL(traffic[index].url);
                        if (selected_domains.hasOwnProperty(url_label)) {
                            upload_traffic[index] = traffic[index];
                        }
                    }
                    chrome.storage.local.set({
                        'selected_domains': {}
                    });
                } else if (options.regex_include == ''
                    || options.regex_include == 'http://*/*, https://*/*') {
                    // If Include patter is empty
                    var url_domains = getURLs(mode);
                    if (Object.keys(url_domains).length > 1) {
                        // If more than one domain in traffic, display overflow with
                        // domain
                        // selection
                        canUpload = false;
                        chrome.extension.sendMessage({
                            op: "domainoverlay",
                            domains: JSON.stringify(url_domains),
                            action: 'export'
                        });
                    }
                }
                if (canUpload) {
                    exportJmeter(upload_traffic);
                }
            });

        callback(true);
    } else if (request.type == 'export_jmeter_follow') {
        var canUpload = true;
        var upload_traffic = traffic_follow;
        chrome.storage.local.get(null,
            function (all) {

                options = all.options;
                var selected_domains = all.selected_domains;

                if (Object.keys(selected_domains).length > 0) {
                    // Then this is step 2, user already selected domains in overlay
                    upload_traffic = {};
                    for (index in traffic_follow) {
                        var url_label = parseURL(traffic_follow[index].url);
                        if (selected_domains.hasOwnProperty(url_label)) {
                            upload_traffic[index] = traffic_follow[index];
                        }
                    }
                    chrome.storage.local.set({
                        'selected_domains': {}
                    });
                } else if (options.regex_include == ''
                    || options.regex_include == 'http://*/*, https://*/*') {
                    // If Include patter is empty
                    var url_domains = getURLs(mode);
                    if (Object.keys(url_domains).length > 1) {
                        // If more than one domain in traffic, display overflow with
                        // domain
                        // selection
                        canUpload = false;
                        chrome.extension.sendMessage({
                            op: "domainoverlay",
                            domains: JSON.stringify(url_domains),
                            action: 'export'
                        });
                    }
                }

                if (canUpload) {
                    exportJmeter(upload_traffic);
                }
            });

        callback(true);
    } else if (request.type == 'download_jmeter') {
        callback(jmx_data_url);
    } else if (request.type == 'traffic_exists') {
        if (JSON.stringify(traffic) != "{}") {
            callback(true);
        } else {
            callback(false);
        }
    } else if (request.type == 'traffic_exists_follow') {
        if (JSON.stringify(traffic_follow) != "{}") {
            callback(true);
        } else {
            callback(false);
        }
    } else if (request.type == 'change_useragent') {
        chrome.storage.local.get('options', function (items) {
            if (items.options.useragent && items.options.useragent != 'Default') {
                useragent = items.options.useragent;
            } else {
                useragent = null;
            }
        });
    } else if (request.type == 'change_regex_follow_input') {
        chrome.storage.local.get('options', function (items) {
            if (items.options.regex_follow_input) {
                options.regex_follow_input = items.options.regex_follow_input;
            } else {
                options.regex_follow_input = '';
            }
        });
    } else if (request.type == 'switch_mode') {
        chrome.storage.local.get('mode', function (items) {
            if (items.mode) {
                mode = items.mode;
            }
        });
    }
    else if (request.type == 'cancel_test') {
        if (record_test_id) {
                if (mode == 'mode-follow') {
                    stopTest(record_test_id);
                }
                else {
                    terminateTest(record_test_id);
                }
        }
        dismissed = true;
        progress_bar = 101; // Stop the progressbar
        record_test_id = null;
        callback(true);
    }
    // Store op in chrome storage so it can be easily retrieved by content
    // script
    chrome.storage.local.set({
        'op': op
    });
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.op == 'json') {
        traffic = JSON.parse(request.json);
        sendResponse({
            success: true
        });
    }
    else if (request.op == 'reloadoptions') {
        //Options are changed, reload them
        if (localStorage.getItem("debug") == 'true') {
            console.log("Debug mode");
            debug = true;
        }
        else {
            debug = false;
        }
        server_url = localStorage.getItem("server");
        if (localStorage.getItem("oldapi") == 'true') {
            console.log("Old API");
            oldapi = true;
        }
        else {
            oldapi = false;
        }
    }
});

function uploadData(traffic) {
    record_test_id = null;
    retries = retries - 1;
    if (retries < 1) {
        retries = 5;
        chrome.extension.sendMessage({
            status: "Sending data failed. Please try again."
        });
        return;
    }
    var traffic_array = new Array();
    for (var items in traffic) {
        traffic_array.push(traffic[items]);
    }

    json = new Object();
    json.traffic = traffic_array;
    chrome.storage.local.get(null, function (all) {
        options = all.options;
        json.name = localStorage.getItem("name");
        json.regex_include = options.regex_include;
        json.top_level = options.top_level;
        json.cookie = options.cookie;
        json = JSON.stringify(json);

        if (debug) {
            console.log("Uploading json to server: ");
            console.log(json);
        }

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4) {
                if (xmlhttp.status != 200) {
                    chrome.extension.sendMessage({
                        status: "Sending data failed. Retrying."
                    });                 
                    return uploadData(traffic);
                } else {
                    retries = 5;
                    var response = JSON.parse(xmlhttp.response);
                    if (response.success || response.id) {
                    	if(!dismissed) {
	                        chrome.extension.sendMessage({
	                            status: "Data uploaded successfully."
	                        });
	                        // update test with concurrency and load origin
	                        concurrency = localStorage.getItem("concurrency");
	                        var geolocation = all.location;
	                        var mode = all.mode;
	                        if(!oldapi) {
	                        	updateTest(response.id, concurrency, geolocation, mode);
	                        } else {
	                        	updateTest(response.test_id, concurrency, geolocation, mode);
	                        }
	                        // start the test if options is off
	                        if (options.options) {
	                            progress_bar = 101; //stop progress bar
	                            // If user wants to adjust options then redirect to blazemeter
	                            // test
								var link = '';
								if(!oldapi) {
									link = server_url + "/app/#test/" + response.id;
								} else {
									link = response.url;
								}
								if (!dismissed && link) {
									chrome.tabs.create({
										url: link
									});
								}
	                        } else {
	                        	 if(!oldapi) {
	                        		 record_test_id = response.id;
	 	                        } else {
	 	                        	record_test_id = response.test_id;
	 	                        }	                        	
	                            // Start test
	                            console.log("starting test");
		                            chrome.extension.sendMessage({
		                                status: "Starting test."
		                            });
	                            startTest(record_test_id);
	                            /*progress_bar = 0;
	                             progressBar();*/
	                        }
                    	}
                    } else {
                        chrome.extension.sendMessage({
                            status: "Server error. Please try again."
                        });
                    }
                }
            }
        }
        if(!oldapi) {
        	xmlhttp.open("POST", server_url + "/api/latest/plugins/chrome/submit?" + API_client_identification(), true);
        } else {
        	xmlhttp.open("POST", server_url + "/api/plugins/chrome/submit?" + API_client_identification(), true);
        }
        xmlhttp.setRequestHeader('Content-type', 'application/json');
        xmlhttp.send(json);
    });
}

function exportJmeter(upload_traffic, upload_mode) {
    retries = retries - 1;
    if (retries < 1) {
        retries = 5;
        chrome.extension.sendMessage({
            status: "Sending data failed. Please try again."
        });
        return;
    }

    var traffic_array = new Array();
    for (var items in upload_traffic) {
        traffic_array.push(upload_traffic[items]);
    }
    json = new Object();
    json.traffic = traffic_array;
    chrome.storage.local.get(null, function (items) {
        options = items.options;
        json.top_level = options.top_level;
        json.cookie = options.cookie;

        if (upload_mode == 'mode-record') {
            json.name = localStorage.getItem("name");
            json.regex_include = options.regex_include;
        } else {
            json.name = items.test_name;
            json.regex_include = options.regex_follow_input;
        }

        json = JSON.stringify(json);

        if (debug) {
            console.log("Uploading json to server: ");
            console.log(json);
        }

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {

            if (xmlhttp.readyState == 4) {
                if (xmlhttp.status != 200) {
                    chrome.extension.sendMessage({
                        status: "Sending data failed. Retrying."
                    });
                    return exportJmeter(upload_traffic);
                } else {
                    retries = 5;
                    chrome.extension.sendMessage({
                        status: "Data converted successfully."
                    });
                    var response = xmlhttp.response;
                    if (response) {
                        var blob = new Blob([ response ], {
                            type: "text/plain"
                        });
                        jmx_data_url = URL.createObjectURL(blob);
                        chrome.tabs.create({
                            url: "download.html"
                        });
                    } else {
                        chrome.extension.sendMessage({
                            status: "Server error. Please try again."
                        });
                    }
                }
            }
        }
        if(!oldapi) {
        	xmlhttp.open("POST", server_url + "/api/latest/plugins/chrome/convert?" + API_client_identification(), true);
        } else {
        	xmlhttp.open("POST", server_url + "/api/plugins/chrome/convert?" + API_client_identification(), true);
        }
        xmlhttp.setRequestHeader('Content-type', 'application/json');
        xmlhttp.send(json);
    });
}

function recordBlink() {

    window.setTimeout(function () {

        btnstate = !btnstate;

        if (incognito === false) {
            if (op == 'pause') {
                if (btnstate) {
                    chrome.browserAction.setIcon({
                        path: "../images/on.png"
                    });
                } else {
                    chrome.browserAction.setIcon({
                        path: "../images/off.png"
                    });
                }
            } else if (op == 'waiting') {
                if (btnstate) {
                    chrome.browserAction.setIcon({
                        path: "../images/on.png"
                    });
                } else {
                    chrome.browserAction.setIcon({
                        path: "../images/off.png"
                    });
                }
            } else {
                if (op == "record" || op == "follow") {
                    chrome.browserAction.setIcon({
                        path: "../images/on.png"
                    });
                } else {
                    chrome.browserAction.setIcon({
                        path: "../images/off.png"
                    });
                    chrome.browserAction.setBadgeText({
                        text: ""
                    });
                }
            }

        } else {

            chrome.tabs.query({}, function (tabs) {
                for (prop in tabs) {
                    if (tabs.hasOwnProperty(prop)) {
                        if (op == 'pause') {
                            if (btnstate) {
                                chrome.browserAction.setIcon({
                                    path: "../images/on.png",
                                    tabId: tabs[prop].id
                                });

                            } else {
                                chrome.browserAction.setIcon({
                                    path: "../images/off.png",
                                    tabId: tabs[prop].id
                                });
                            }
                        } else if (op == 'waiting') {
                            if (btnstate) {
                                chrome.browserAction.setIcon({
                                    path: "../images/on.png",
                                    tabId: tabs[prop].id
                                });
                            } else {
                                chrome.browserAction.setIcon({
                                    path: "../images/off.png",
                                    tabId: tabs[prop].id
                                });
                            }
                        } else {
                            if (op == "record" || op == "follow") {
                                chrome.browserAction.setIcon({
                                    path: "../images/on.png",
                                    tabId: tabs[prop].id
                                });
                            } else {
                                chrome.browserAction.setIcon({
                                    path: "../images/off.png",
                                    tabId: tabs[prop].id
                                });
                                chrome.browserAction.setBadgeText({
                                    text: "",
                                    tabId: tabs[prop].id
                                });
                            }
                        }
                    }
                }
            });
        }
        recordBlink();
    }, 500);
}

function drawBadgeDynamic() {

    if (incognito === false) {
        chrome.browserAction.setBadgeBackgroundColor({
            color: "#d90a16"
        });
        if (counter > 9999) {
            if (counter <= 999999) {
                thousand_items = Math.floor(counter / 1000);
                badgeText = thousand_items + "k";
            } else {
                badgeText = "9999"; // infinite
            }
        } else {
            badgeText = counter.toString();
            chrome.browserAction.setBadgeText({
                text: badgeText
            });
        }

    } else {

        chrome.tabs.query({}, function (tabs) {
            for (prop in tabs) {
                if (tabs.hasOwnProperty(prop)) {
                    chrome.browserAction.setBadgeBackgroundColor({
                        color: "#d90a16",
                        tabId: tabs[prop].id
                    });
                    if (counter > 9999) {
                        if (counter <= 999999) {
                            thousand_items = Math.floor(counter / 1000);
                            badgeText = thousand_items + "k";
                        } else {
                            badgeText = "9999"; // infinite
                        }
                    } else {
                        badgeText = counter.toString();
                        chrome.browserAction.setBadgeText({
                            text: badgeText,
                            tabId: tabs[prop].id
                        });
                    }
                }
            }
        });
    }
}

function waitUntilTestIsReady() {
    if (op != 'waiting') {
        progress_bar = 0;
        chrome.extension.sendMessage({
            op: "progressbar",
            progress: progress_bar
        });
        //console.log("Test is aborted?");
        return;
    }

    if (test_id || session_id) {
        var test_status = testStatus();
        //chrome.storage.local.get('test_status', function (data) {
            //var test_status = data.test_status;
            if(debug) {
                console.log(test_status);
            }

            if (test_status == 'Ready') {
                if (continue_old_test && continue_old_test_state == 'fail') {
                    continue_old_test = false;
                    continue_old_test_state = 'none';
                    return;
                }
                else if (continue_old_test && continue_old_test_state == 'success') {
                    continue_old_test = false;
                    continue_old_test_state = 'none';
                }
                // signal to enable interface
                progress_bar = 0;
                chrome.extension.sendMessage({
                    op: "progressbar",
                    progress: progress_bar
                });
                chrome.extension.sendMessage({
                    waiting: "ready"
                });
                chrome.extension.sendMessage({
                    status: ""
                });

                op = 'follow';

                startRecording();
                /*chrome.storage.local.set({
                    'test_status': test_status
                });*/
                //start pulling server for test status
                testIsAlive();
                console.log("BlazeMeter: started recording traffic");
                return;
            }
            /*else {
                //testStatus(test_id);
                var test_status = testStatus();
            }*/
        //});
    }
    /*else {
        console.log("test not created yet");
    }*/

    progress_bar++;
    if (progress_bar > 100) {
        progress_bar = 1;
    }
    chrome.extension.sendMessage({
        op: "progressbar",
        progress: progress_bar,
        follow: true,
        test_id: test_id
    });

    /*chrome.storage.local.set({
        'test_status': "Not ready"
    });*/
    window.setTimeout(function () {
        waitUntilTestIsReady();
    }, 3000);
}

function testIsAlive() {
    if (test_id && op == 'follow') {
        //@todo: or paused?
        //chrome.storage.local.get('test_status', function (data) {
            //var test_status = data.test_status;
        var test_status = testStatus();
            if (test_status != 'Ready') {
                chrome.storage.local.set({
                    'stopped_test': true
                });
                // signal that test is stopped on backend
                chrome.extension.sendMessage({
                    op: "testendedoverlay"
                });
                stopRecording();
                op = 'stopped';
                console.log("BlazeMeter: test was stopped on the backend");
            } else {
                //testStatus(test_id);
                //poll the backend for the status, every 30 seconds
                window.setTimeout(function () {
                    testIsAlive();
                }, 30000);
            }
        //});
    }
}

function testStatus() {
    var status = 'Not ready';
        var xmlhttp = new XMLHttpRequest();
        try {
        if(oldapi) {
            xmlhttp.open("GET", server_url + "/api/followme/tests/" + test_id + "/status?" + API_client_identification(), false);
            xmlhttp.send();
        }
        else {
            xmlhttp.open("GET", server_url + "/api/latest/sessions/" + session_id + "/?" + API_client_identification(), false);
            if(session_id) {
                xmlhttp.send();
            }
        }
        }
        catch (e) {
        	if(e.name = "NetworkError") {
        		chrome.extension.sendMessage({
                    op: "network_error"
                });
        	}
        }
        if (xmlhttp.status === 200) {
            var response = JSON.parse(xmlhttp.response);
            if(oldapi){
                status = response.status;
            }
            else {
                if(response.result.statusCode >= 70 && response.result.statusCode <= 100) {
                    status = 'Ready';
                }
                else {
                    status = 'Not ready';
                }
            }
        }

    return status;
}

function createTest(name, threads, geolocation) {
    var xmlhttp = new XMLHttpRequest();
    session_id = null;
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
        	var response = JSON.parse(xmlhttp.response);
            if (xmlhttp.status === 200) {
                if(!oldapi) {
                	test_id = response.result.id;
                } else {
                	test_id = response.test_id;
                }
                if (test_id) {                    
                    chrome.storage.local.set({
                        'test_id': test_id
                    });
                    // Start the test
                    startTest(test_id);
                }
            }
            else {
                //in case of failure we have HTTP 406.
            	op = 'stopped';
            	chrome.storage.local.set({
                    'op': op
                });
                console.log("Failed to create the test.");
                // abort and enable interface
                chrome.extension.sendMessage({
                    waiting: "failed"
                });
                if(!oldapi) {
                    chrome.extension.sendMessage({
                        status : "Failed to start the test. Error: " + response.error.message
                        });
                } else  {
                    chrome.extension.sendMessage({
                        status : "Failed to start the test. Error: " + response.error
                        });	
                }
                //Since user will probably close popup while waiting, instead of printing error inside the popup we will alert him
                //@todo: alert is not displayed anymore? New Chrome permissions?
                //alert("Failed to start the test. Error: " + error);
                dismissed = true;
                progress_bar = 101; // Stop the progressbar
            }
        }
    }
    var sendxml = '';
    if(!oldapi) {
    	var concurrency = localStorage.getItem("concurrency");
        var serversCount = 0;
        if(concurrency > 1000) {
          //if the number of users is > 1000 the serverCount should be calculated
            serversCount = Math.ceil(concurrency/1000);
        }
    	//var time_distribution = localStorage.getItem("time-distribution");
    	xmlhttp.open("POST", server_url + "/api/latest/tests?" + API_client_identification(), true);
    	xmlhttp.setRequestHeader('Content-type', 'application/json');
        var createFollowmeJson = {
        		   "name":name,
        		   "configuration":{
        		      "location":geolocation,
        		      "type":"followme",
        		      "serversCount":serversCount,
        		      "plugins":{
        		         "followme":{
        		            "samplers":[
        		            ]
        		         }
        		      }
        		   }
        		};
        sendxml = JSON.stringify(createFollowmeJson);
    } else {
    	xmlhttp.open("POST", server_url + "/api/followme/tests/create?" + API_client_identification(), true);
    	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        sendxml = 'threads=' + encodeURIComponent(threads) + '&location='
            + encodeURIComponent(geolocation) + '&name=' + encodeURIComponent(name);
    }
    xmlhttp.send(sendxml);
}

function updateTest(test_id, threads, geolocation, mode) {
    var xmlhttp = new XMLHttpRequest();
    var params = '';
    var concurrency = localStorage.getItem("concurrency");
    var duration = localStorage.getItem("duration");
    if(duration < 1) {
    	duration = 20;
    }
    if(!oldapi) {
    	xmlhttp.open("PUT", server_url + "/api/latest/tests/" + test_id + "?" + API_client_identification(), false);
    	if (mode == 'mode-follow') {
		  	params = {
                "configuration": {
                    "location": geolocation
                }
            };
		} else {
				params = {
                "configuration": {
                    "location": geolocation,
					"concurrency": concurrency
                    //Temp fix for Requested amount of duration (50) exceeds the plan limits (20)
                    /*"plugins": {
                        "jmeter": {
                            "override": {
                                "duration": duration
                            }
                        }
                    }*/
                }
            };
		}
    	params = JSON.stringify(params);
    	xmlhttp.setRequestHeader('Content-type', 'application/json');
    } else {
    	xmlhttp.open("POST", server_url + "/api/followme/tests/" + test_id + "/update?" + API_client_identification(), false);
       params = 'threads=' + encodeURIComponent(threads) + '&location='
        + encodeURIComponent(geolocation);
       xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    }
    xmlhttp.send(params);
    var response = JSON.parse(xmlhttp.response);
    if (xmlhttp.status === 200) {
        if (!response.error) {
            if (mode == 'mode-follow') {
                if(!oldapi) {
                	startTest(test_id);
                  } else {
                      var test_status = testStatus();
                      if (test_status != "Ready") {
                          // Start the test
                          startTest(test_id);
                      }
                      else {
                          continue_old_test_state = 'success';
                      }
                  }
                /*chrome.storage.local.set({
                 'test_status': status
                 });*/
            }
        } else {
            console.log("Failed to update the test.");
            // abort and enable interface
            if (mode == 'mode-follow') {
                op = null;
                chrome.extension.sendMessage({
                    waiting: "failed"
                });
            }
            chrome.extension.sendMessage({
                status: response.error
            });
        }
    } else {
        if(!oldapi) {
            var error = response.error.message;
            chrome.extension.sendMessage({
                status: error
            });
            if (mode == 'mode-follow') {
                op = 'stopping';
                chrome.extension.sendMessage({
                    waiting: "failed"
                });
            }
          }
    }
    return null;
}

function startTest(test_id) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
        	var response = JSON.parse(xmlhttp.response);
            if (xmlhttp.status === 200) {
            	if(!dismissed || mode == 'mode-follow') {
                console.log("Starting test");                
                if(!oldapi) {
                	session_id = response.result.sessionsId[0];
                    //Store session_id, we need it to open report page
                    chrome.storage.local.set({
                        'session_id': session_id
                    });
                } else {
                	session_id = response.session_id;
                    error = response.error;
                }
                if (!session_id && !continue_old_test) {
                    // failed to start the test
                    console.log("Failed to start the test.");
                    // abort and enable interface
                    op = "stopped";

                    chrome.extension.sendMessage({
                        waiting: "failed"
                    });
                    /*chrome.extension.sendMessage({
                     status : "Failed to start the test. Error: " + response.error
                     });*/
                    //Since user will probably close popup while waiting, instead of printing error inside the popup we will alert him
                    chrome.extension.sendMessage({
                        status: "Failed to start the test. Error: " + error
                    });
                    dismissed = true;
                    progress_bar = 101; // Stop the progressbar
                } else if (!session_id && continue_old_test) {
                    // failed to start the test
                    console.log("Failed to start the test.");
                    // abort and enable interface
                    op = "stopped";

                    chrome.extension.sendMessage({
                        waiting: "failed"
                    });
                    chrome.extension.sendMessage({
                        status: "Failed to start the test. Error: " + error
                    });

                    continue_old_test_state = 'fail';

                } else if (session_id && continue_old_test) {
                    continue_old_test_state = 'success';
                    chrome.extension.sendMessage({
                        status: "You can now start testing!"
                    });
                } else if (session_id && !continue_old_test && op != 'stopped') {
                    chrome.extension.sendMessage({
                        status: "You can now start testing!"
                    });
                }
             }
          } else {
              if(!oldapi) {
                  var error = response.error.message;
                  console.log("Failed to start the test.");
                  op = "stopped";

                  chrome.extension.sendMessage({
                      waiting: "failed"
                  });
                  chrome.extension.sendMessage({
                      status: "Failed to start the test. Error: " + error
                  });

                  continue_old_test_state = 'fail';
              }
          }
        }
    }
    if(!oldapi) {
    	xmlhttp.open("POST", server_url + "/api/latest/tests/" + test_id + "/start?" + API_client_identification(), true);
    } else {
    	xmlhttp.open("GET", server_url + "/api/followme/tests/" + test_id + "/start?" + API_client_identification(), true);
    }
    var ret = xmlhttp.send();
}

function stopTest(test_id) {
	if(test_id != null){
	    console.log("Stopping test " + test_id);
	    var xmlhttp = new XMLHttpRequest();
	    xmlhttp.onreadystatechange = function () {

	        if (xmlhttp.readyState == 4) {
	            if (xmlhttp.status === 200) {
	                console.log("Test stopped");
	                if (xmlhttp.error) {
	                    console.log(xmlhttp.error);
	                }
	            }
	        }
	    }
	    if(!oldapi) {
	    	xmlhttp.open("GET", server_url + "/api/latest/tests/" + test_id + "/stop?" + API_client_identification(), false);
	    } else {
	    	xmlhttp.open("GET", server_url + "/api/followme/tests/" + test_id + "/stop?" + API_client_identification(), true);
	    }
	    
	    try {
	    	xmlhttp.send();
	    }
	    catch (e) {
	    	console.log(e.message);
	    }
	}
}

function terminateTest(test_id) {
    console.log("Terminating test " + test_id);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {

        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status === 200) {
                console.log("Test terminated");
                if (xmlhttp.error) {
                    console.log(xmlhttp.error);
                }
            }
        }
    }
    if(!oldapi) {
    	xmlhttp.open("GET", server_url + "/api/latest/tests/" + test_id + "/terminate?" + API_client_identification(), true);
    } else {
    	xmlhttp.open("GET", server_url + "/node/" + test_id + "/terminate/1?" + API_client_identification(), true);
    }
    xmlhttp.send();
}

function progressBar() {
    progress_bar++;
    chrome.extension.sendMessage({
        op: "progressbar",
        progress: progress_bar
    });
    if (progress_bar <= 100) {
        chrome.extension.sendMessage({
            op: "progressbar",
            progress: progress_bar
        });
        window.setTimeout(function () {
            progressBar();
        }, 1200);
    } else {
        chrome.extension.sendMessage({
            op: "progressbar",
            progress: 0
        });
        var link = '';
        if(!oldapi) {
        	link = server_url + "/app/#test/" + record_test_id;
        } else {
        	link = server_url + "/node/" + record_test_id + "/gjtl";
        }
        if (!dismissed && record_test_id) {
            chrome.tabs.create({
                url: link
            });
        }
    }
}

function getURLs(mode) {
    var url_list = {};
    if (mode == 'mode-record') {
        for (index in traffic) {
            var url_label = parseURL(traffic[index].url);
            if (!url_list[url_label]) {
                url_list[url_label] = url_label;
            }
        }
    } else {
        for (index in traffic_follow) {
            var url_label = parseURL(traffic_follow[index].url);

            if (!url_list[url_label]) {
                url_list[url_label] = url_label;
            }
        }
    }
    return url_list;
}

function setProperty(test_id, step, request, concurrency, time_distribution) {
    var xmlhttp = new XMLHttpRequest();
    var params = '';

    if (time_distribution == '0' || time_distribution == null) {
        time_distribution = localStorage.getItem('auto_time_distribution');
    }
    if(!oldapi) {
        parser.href = request.url;
        var host = parser.hostname;
        var protocol = parser.protocol.replace(':','');
        var port = (parser.port) ? parser.port : 80;

        var path = parser.pathname + parser.search +  parser.hash;
    	var createJson = [{
 			   "concurrency":concurrency,
 			   "time_distribution":time_distribution,
 			   "label":request.label,
 			   "method":request.method,
 			   "protocol":protocol,
 			   "host":host,
 			   "port":port,
 			   "path":path,
 			   "headers":request.headers,
 			   "body":request.body
 			}];
        console.log(createJson);
    	params = JSON.stringify(createJson);
    	xmlhttp.open("POST", server_url + "/api/latest/sessions/" + test_id + "/followme?" + API_client_identification(), true);
    	xmlhttp.setRequestHeader('Content-type', 'application/json');
    } else {
    	xmlhttp.open("POST", server_url + "/node/" + test_id + "/command?ajax=true&" + API_client_identification(), true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        var jsonObject = [];
        jsonObject.push({
            name: 'setvar',
            args: {
                'name': 'step',
                'val': step
            }
        });
        jsonObject.push({
            name: 'setvar',
            args: {
                'name': 'domainfilter' + step,
                'val': options.regex_follow_input
            }
        });
        jsonObject.push({
            name: 'setvar',
            args: {
                'name': 'sampler' + step,
                'val': request
            }
        });
        jsonObject.push({
            name: 'setvar',
            args: {
                'name': 'concurrency' + step,
                'val': concurrency
            }
        });

        jsonObject.push({
            name: 'setvar',
            args: {
                'name': 'timedistribution' + step,
                'val': time_distribution
            }
        });
        params = 'commands=' + encodeURIComponent(JSON.stringify(jsonObject)) + '&target=all';
    }
    xmlhttp.send(params);
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status === 200) {
                //console.log(xmlhttp.response);
            }
        }
    }
}

function parseURL(url) {
    parsed_url = {}

    if (url == null || url.length == 0)
        return parsed_url;

    protocol_i = url.indexOf('://');

    remaining_url = url.substr(protocol_i + 3, url.length);
    domain_i = remaining_url.indexOf('/');
    domain_i = domain_i == -1 ? remaining_url.length - 1 : domain_i;
    parsed_url.domain = remaining_url.substr(0, domain_i);

    domain_parts = parsed_url.domain.split('.');
    switch (domain_parts.length) {
        case 2:
            parsed_url.host = domain_parts[0];
            parsed_url.tld = domain_parts[1];
            break;
        case 3:
            parsed_url.host = domain_parts[1];
            parsed_url.tld = domain_parts[2];
            break;
        case 4:
            parsed_url.host = domain_parts[1];
            parsed_url.tld = domain_parts[2] + '.' + domain_parts[3];
            break;
    }

    parent_domain = parsed_url.host + '.' + parsed_url.tld;

    return parent_domain;
}

function API_client_identification() {
    var manifest = chrome.runtime.getManifest();
    return "_clientId=BE_CHROME&_clientVersion=​" + manifest.version;
}