chrome.extension.sendRequest({
    type: 'download_jmeter'
}, function (fileURL) {
    var link = document.createElement('a');
    var name = localStorage.getItem("jmxname");
    link.download = name + ".jmx";
    link.href = fileURL;
    link.click();
    chrome.tabs.getCurrent(function (tab) {
        chrome.tabs.remove(tab.id, function () {
        });
    });
});
