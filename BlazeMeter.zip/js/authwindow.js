var authCredentials = window.dialogArguments;

document.addEventListener('DOMContentLoaded', function () {
    console.log(authCredentials);
    document.getElementById('submit').onclick = function () {
        authCredentials.authCredentials.username = document.getElementById("username").value;
        authCredentials.authCredentials.password = document.getElementById("password").value;
        window.returnValue = authCredentials;
        window.close();

    }
});
