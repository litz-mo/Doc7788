var name_default = "Name: ";
document.addEventListener("DOMContentLoaded", function () {
    $(window).resize(function () {
        adjustSubmitButton();
    });
    //Overlay close button
    document.querySelector('#run-overlay .close').addEventListener('click', closeOverlay);
    //document.querySelector('#run-overlay .progress-body .button').addEventListener('click', dismissTest);
    chrome.extension.onMessage.addListener(
        function (request, sender, sendResponse) {
            if (request.status) {
                var status = document.getElementById("status");
                status.innerHTML = request.status;
            }
            else if (request.op == "progressbar") {
                chrome.storage.local.get('mode', function (data) {
                    if (data.mode == 'mode-record') {
                        if (request.progress) {
                            waitOverlay(request.progress);
                        }
                        else {
                            $("#run-overlay .progress-body").hide();
                            closeOverlay();
                        }
                    }
                });
            }
            else if (request.op == "domainoverlay") {
                var status = document.getElementById("status");
                status.innerHTML = '';

                if (request.action == 'upload') {
                    document.querySelector('#run-overlay .domains-body .button').removeEventListener('click', exportSelectedDomains);
                    document.querySelector('#run-overlay .domains-body .button').addEventListener('click', uploadSelectedDomains);
                }
                else if (request.action == 'export') {
                    document.querySelector('#run-overlay .domains-body .button').removeEventListener('click', uploadSelectedDomains);
                    document.querySelector('#run-overlay .domains-body .button').addEventListener('click', exportSelectedDomains);
                }
                domainOverlay(JSON.parse(request.domains));
                adjustSubmitButton();
            }
        });

    var container = document.getElementById("jsoneditor");
    var editor = new jsoneditor.JSONEditor(container);
    chrome.extension.sendRequest({
        type: 'get_traffic'
    }, function (data) {
        if (data) {
            var traffic = JSON.parse(data);
            editor.set(traffic);
        }
    });
    document.querySelector('#upload').addEventListener('click', uploadData);
    document.querySelector('#export-json').addEventListener('click', exportJson);
    document.querySelector('#upload-jmx').addEventListener('click', exportJmeter);

    if (localStorage.getItem("name")) {
        document.getElementById("name").value = localStorage.getItem("name");
        enableBtn("export-json");
    }
    else {
        document.getElementById("name").value = name_default;
        disableBtn("export-json");
    }

    if (localStorage.getItem("name") && isLogged()) {
        enableBtn("upload");
        enableBtn("upload-jmx");
    }
    else {
        disableBtn("upload");
        disableBtn("upload-jmx");
        if (!isLogged()) {
            document.getElementById("upload-off").title = "You must log in to upload and create a new test.";
        }
    }

    document.querySelector('#name').onfocus = function () {
        if (this.value == name_default) {
            this.value = "";
        }
    };
    document.querySelector('#name').onblur = function () {
        if (this.value == "") {
            this.value = name_default;
        }
    };

//Save name on out of focus
    document.querySelector('#name').onkeyup = function () {
        if (document.getElementById("name").value != name_default) {
            localStorage.setItem("name", document.getElementById("name").value);
        }
        if (document.getElementById("name").value == "") {
            disableBtn("upload");
            disableBtn("export-json");
            disableBtn("upload-jmx");
        }
        else {
            enableBtn("upload");
            enableBtn("export-json");
            enableBtn("upload-jmx");
        }

        if (!isLogged()) {
            disableBtn("upload");
            disableBtn("upload-jmx");
            document.getElementById("upload-off").title = "You must log in to upload and create a new test.";
        }
        else if (document.getElementById("name").value != "") {
            enableBtn("upload");
            enableBtn("upload-jmx");
            document.getElementById("upload-off").title = "Adjust test properties and run from the cloud.";
        }
    };

    //Tipsy
    $('.tipsy-btn').tipsy({gravity: 'ne'});

    function uploadData() {
        var traffic = editor.get();
        chrome.runtime.sendMessage({op: "json", json: JSON.stringify(traffic)}, function (response) {
            chrome.extension.sendRequest({
                type: 'upload_traffic'
            }, function (data) {
                //var status = document.getElementById("status");
                //status.innerHTML = "<img src='../images/upload-editor.gif'/>";
            });
        });
    }

    function exportJson() {
        var traffic = editor.get();
        chrome.runtime.sendMessage({op: "json", json: JSON.stringify(traffic)}, function (response) {
            chrome.extension.sendRequest({
                type: 'get_json'
            }, function (json_string) {
                if (json_string) {
                    var blob = new Blob([json_string], {type: "application/json"});
                    var url = URL.createObjectURL(blob);
                    var link = document.createElement('a');
                    link.download = document.getElementById("name").value + ".json";
                    link.href = url;
                    link.click();
                }
            });
        });
    }

    function exportJmeter() {
        var traffic = editor.get();
        var status = document.getElementById("status");
        var value = $("#name").val();
        localStorage.setItem("jmxname", value);
        status.innerHTML = "Converting...";
        chrome.runtime.sendMessage({op: "json", json: JSON.stringify(traffic)}, function (response) {
            chrome.extension.sendRequest({
                type: 'export_jmeter'
            }, function (data) {
            });
        });
    }

    function adjustSubmitButton() {
        var windowheight = $(window).height();
        var xpos = $('.include-domains').position().top;
        $(".include-domains").height(windowheight - xpos - 250);
    }
});
