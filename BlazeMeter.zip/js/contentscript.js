/*var file;
 $('input[type=file]').change(function(e){
 file = e.target.files[0];
 console.log(e);
 var reader = new FileReader();
 reader.onload = function (event) {
 console.log(event.target.result);  //contains the file data
 //maybe change data and use filewriter

 };
 reader.readAsDataURL(file);
 });
 */
var form = document.forms["uploadForm"];
for (var i = 0; i < document.forms.length; i++) {
    var form = document.forms[i];
    console.log(form);
    form.addEventListener('submit', form.addEventListener('submit', function (ev) {
        //ev.preventDefault(); // Cancel submission

        var fileInput = form.querySelector('input[type="file"]');
        var file = fileInput.files[0];
        console.log(file);
        /*if (!file) return; // No file selected

         var fileReader = new FileReader();
         fileReader.onload = function() {
         var arraybuffer = fileReader.result;
         // To manipulate an arraybuffer, wrap it in a view:
         var view = new Uint8Array(arraybuffer);
         view[0] = 0; // For example, change the first byte to a NULL-byte

         // Create an object which is suitable for use with FormData
         var blob = new Blob([view], {type: file.type});

         // Now, the form reconstruction + upload part:
         var formData = new FormData();
         formData.append(fileInput.name, blob, file.name);
         // ... handle remainder of the form ...

         // Now, submit the form
         var xhr = new XMLHttpRequest();
         xhr.open('POST', form.action);
         xhr.onload = function() {
         // Do something. For example:
         alert(xhr.responseText);
         };
         xhr.onerror = function() {
         console.log(xhr); // Aw. Error. Log xhr object for debugging
         }
         xhr.send(formData);
         };
         fileReader.readAsArrayBuffer(file);*/
    }));
}
