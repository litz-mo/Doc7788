// Save this script as `options.js`


// Saves options to localStorage.
function save_options() {
    if (document.getElementById("debug").checked) {
        localStorage["debug"] = true;
    }
    else {
        localStorage["debug"] = false;
    }

    localStorage["server"] = document.getElementById("server").value;

    //BPFR-228: Need to implement some hidden property in settings (checkbox) to navigate to d6
    if (document.getElementById("oldapi").checked) {
        localStorage["oldapi"] = true;
    }
    else {
        localStorage["oldapi"] = false;
    }

    //Reload options
    chrome.extension.sendMessage({
        op: "reloadoptions"
    });

    //Close the options page
    chrome.tabs.getCurrent(function(tab) {
        chrome.tabs.remove(tab.id, function() { });
    });
}

document.addEventListener("DOMContentLoaded", function () {
    if (localStorage["debug"] == 'true') {
        document.getElementById("debug").checked = true;
    }
    document.getElementById("server").value = localStorage["server"];
    if (localStorage["oldapi"] == 'true') {
        document.getElementById("oldapi").checked = true;
    }
});

document.querySelector('#save').addEventListener('click', save_options);